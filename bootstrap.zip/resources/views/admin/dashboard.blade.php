@extends('layouts.dashboard')
@section('title', 'Dashboard Admin')

@section('content')
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">

  <h1 class="text-3xl font-semibold tracking-tight text-gray-900">Bem-vindo, {{ auth()->user()->name }}</h1>
  <p class="text-sm text-gray-500 mt-1">Visão geral do sistema.</p>

  {{-- KPIs --}}
  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
    <div class="bg-white rounded-lg shadow-sm p-5">
      <p class="text-sm text-gray-500">Utilizadores</p>
      <p class="text-3xl font-semibold text-gray-900">{{ number_format($totUsers) }}</p>
    </div>
    <div class="bg-white rounded-lg shadow-sm p-5">
      <p class="text-sm text-gray-500">Médicos registados</p>
      <p class="text-3xl font-semibold text-gray-900">{{ number_format($totMedicos) }}</p>
    </div>
    <div class="bg-white rounded-lg shadow-sm p-5">
      <p class="text-sm text-gray-500">Consultas (ativas)</p>
      <p class="text-3xl font-semibold text-gray-900">{{ number_format($totConsultas) }}</p>
    </div>
    <div class="bg-white rounded-lg shadow-sm p-5">
      <p class="text-sm text-gray-500">Hoje / Este mês</p>
      <p class="text-xl font-semibold text-gray-900">{{ $consultasHoje }} <span class="text-gray-400">/</span> {{ $consultasMes }}</p>
    </div>
  </div>

  {{-- Filtros de datas para os gráficos --}}
  <div class="mt-8 flex items-center gap-3">
    <div class="text-sm text-gray-600">Período:</div>
    <input type="date" id="dashStart" class="border rounded px-2 py-1 text-sm">
    <span class="text-gray-400">—</span>
    <input type="date" id="dashEnd" class="border rounded px-2 py-1 text-sm">
  </div>

  {{-- Gráficos --}}
  <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
    <div class="bg-white rounded-lg shadow-sm p-4 md:p-6 lg:col-span-2">
      <div class="flex items-center justify-between">
        <h5 class="text-xl font-bold text-gray-900">Consultas por dia</h5>
      </div>
      <div id="chart-by-day" class="py-4"></div>
      <p class="text-xs text-gray-500">Total diário no período.</p>
    </div>

    <div class="bg-white rounded-lg shadow-sm p-4 md:p-6">
      <div class="flex items-center justify-between">
        <h5 class="text-xl font-bold text-gray-900">Estados das consultas</h5>
      </div>
      <div id="chart-status" class="py-4"></div>
      <p class="text-xs text-gray-500">Distribuição de estados.</p>
    </div>

    <div class="bg-white rounded-lg shadow-sm p-4 md:p-6 lg:col-span-3">
      <div class="flex items-center justify-between">
        <h5 class="text-xl font-bold text-gray-900">Consultas por especialidade</h5>
      </div>
      <div id="chart-esps" class="py-4"></div>
      <p class="text-xs text-gray-500">Top especialidades no período.</p>
    </div>
  </div>
</div>

{{-- ApexCharts via CDN --}}
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
@vite('resources/js/pages/dashboard-admin.js')
@endsection
