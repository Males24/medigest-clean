{{-- resources/views/layouts/dashboard.blade.php --}}
<!DOCTYPE html>
<html lang="{{ str_replace('_','-',app()->getLocale() ?: 'pt-PT') }}">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <meta name="color-scheme" content="light">
  <title>@yield('title', 'Dashboard') • MediGest+</title>

  <link rel="preload" as="image" href="{{ asset('/Logo_Preto.svg') }}">

  @vite(['resources/css/app.css', 'resources/js/app.js'])
  @stack('head')
</head>

<body class="bg-gray-100 text-gray-900 antialiased">

  {{-- Link A11y para saltar conteúdo --}}
  <a href="#conteudo-principal"
     class="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50
            bg-white text-gray-900 rounded px-3 py-2 shadow">
    Saltar para o conteúdo
  </a>

  {{-- HEADER (fixo no topo) --}}
  <header class="bg-white border-b border-gray-200 px-4 sm:px-6 py-3 sticky top-0 z-40">
    <div class="max-w-[1430px] mx-auto flex items-center gap-3 justify-between">

      {{-- Botão sidebar (mobile) --}}
      <button id="sidebar-toggle"
              class="lg:hidden inline-flex items-center justify-center rounded-lg p-2
                     text-gray-700 hover:bg-gray-100"
              aria-controls="layout-sidebar" aria-expanded="false">
        <span class="sr-only">Alternar menu</span>
        <svg viewBox="0 0 24 24" class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2"
             stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <path d="M3 6h18M3 12h18M3 18h18"/>
        </svg>
      </button>

      <a href="{{ route('home') }}" class="inline-flex items-center shrink-0" aria-label="Página inicial MediGest+">
        <img src="{{ asset('/Logo_Preto.svg') }}" alt="MediGest+" class="h-8 sm:h-10 w-auto select-none" loading="eager" fetchpriority="high">
      </a>

      @auth
        @php
          $u = auth()->user();
          $avatar = 'https://ui-avatars.com/api/?name=' . urlencode($u->name)
                  . '&background=E5E7EB&color=00795C&bold=true&format=svg&size=64';
        @endphp

        {{-- User dropdown --}}
        <div class="relative">
          <button id="user-menu-button" type="button"
                  class="inline-flex items-center gap-2 rounded-full ps-1 pe-2 py-1
                         text-sm font-medium text-gray-900 hover:text-home-medigest
                         focus:outline-none focus-visible:ring-2 focus-visible:ring-home-medigest/40"
                  aria-expanded="false" aria-haspopup="menu" aria-controls="user-dropdown">
            <span class="sr-only">Abrir menu do utilizador</span>

            <img class="w-9 h-9 rounded-full shadow-sm ring-1 ring-gray-200"
                 src="{{ $avatar }}" alt="Avatar de {{ $u->name }}" width="36" height="36"
                 decoding="async" loading="lazy" referrerpolicy="no-referrer">

            <span class="hidden sm:inline font-semibold max-w-[16ch] truncate">{{ $u->name }}</span>

            <svg class="w-3.5 h-3.5 ms-0.5 text-gray-600" viewBox="0 0 10 6" fill="none" aria-hidden="true">
              <path d="m1 1 4 4 4-4" stroke="currentColor" stroke-width="2"
                    stroke-linecap="round" stroke-linejoin="round" />
            </svg>
          </button>

          <div id="user-dropdown"
            class="hidden absolute right-0 mt-2 w-64 origin-top-right rounded-xl border
                    border-gray-200 bg-white shadow-lg focus:outline-none z-50"
            role="menu" aria-labelledby="user-menu-button" tabindex="-1">
            <div class="px-4 py-3 text-sm bg-zinc-100 rounded-t-xl">
              <div class="font-semibold truncate text-gray-900">{{ $u->name }}</div>
              <div class="text-xs text-gray-600 truncate">{{ $u->email }}</div>
            </div>

            <ul class="py-1 text-sm text-gray-800" role="none">
              <li>
                <a href="#"
                   class="block px-4 py-2 hover:bg-gray-100 rounded"
                   role="menuitem" tabindex="-1">
                  Configurações
                </a>
              </li>
            </ul>

            <div class="py-1">
              <form method="POST" action="{{ route('logout') }}" role="none">
                @csrf
                <button type="submit"
                        class="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 rounded-b-xl"
                        role="menuitem" tabindex="-1">
                  Terminar sessão
                </button>
              </form>
            </div>
          </div>
        </div>
      @endauth
    </div>
  </header>

  {{-- LAYOUT --}}
  @php
    $role = optional(auth()->user())->role;
    $base     = 'block px-3 py-2 rounded-md transition focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00795C]/40';
    $active   = 'bg-gray-900 text-white';
    $inactive = 'text-gray-700 hover:bg-gray-200';
    $dashboardRoute = match ($role) {
      'admin'    => 'admin.dashboard',
      'medico'   => 'medico.dashboard',
      'paciente' => 'paciente.home',
      default    => 'home',
    };
    $isActive = fn($pattern) => request()->routeIs($pattern) ? "$base $active" : "$base $inactive";
  @endphp

  <div class="relative">
    <div class="flex min-h-[calc(100vh-64px)]">
      {{-- SIDEBAR --}}
        <aside id="layout-sidebar"
            class="w-64 shrink-0 bg-gray-100 lg:static lg:transform-none
                    lg:h-auto lg:top-auto lg:left-auto
                    lg:translate-x-0 transition-transform duration-200
                    border-r border-gray-200 p-4 overflow-y-auto z-30">
        <nav aria-label="Menu lateral" class="space-y-2">
          <a href="{{ route($dashboardRoute) }}" class="{{ $isActive($dashboardRoute) }}">{{ __('Dashboard') }}</a>

          @if ($role === 'medico')
            <a href="{{ route('medico.consultas.index') }}"  class="{{ $isActive('medico.consultas.index') }}">Consultas Atribuídas</a>
            <a href="{{ route('medico.consultas.create') }}" class="{{ $isActive('medico.consultas.create') }}">Criar Consulta</a>
          @endif

          @if ($role === 'admin')
            <a href="{{ route('admin.consultas.index') }}"        class="{{ $isActive('admin.consultas.index') }}">Todas as Consultas</a>
            <a href="{{ route('admin.especialidades.index') }}"  class="{{ $isActive('admin.especialidades.*') }}">Especialidades</a>
            <a href="{{ route('admin.medicos.index') }}"         class="{{ $isActive('admin.medicos.*') }}">Criar Médico</a>
            <a href="{{ route('admin.horarios.index') }}"        class="{{ $isActive('admin.horarios.*') }}">Horários</a>
          @endif
        </nav>
      </aside>

      {{-- OVERLAY mobile --}}
        <div id="sidebar-scrim"
            class="lg:hidden fixed left-0 right-0 bg-black/40 transition-opacity z-20"
            aria-hidden="true"></div>

      {{-- CONTEÚDO --}}
      <main id="conteudo-principal" class="flex-1 p-4 sm:p-6 overflow-y-auto">
        @yield('content')
      </main>
    </div>
  </div>

  @stack('body-end')
</body>
</html>
