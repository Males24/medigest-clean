import './bootstrap';
import 'flowbite';
import './layout/dropdownMenu';
import './layout/user-menu.js';
import './layout/sidebar.js';

import Alpine from 'alpinejs';

window.Alpine = Alpine;
Alpine.start();