// resources/js/layout/user-menu.js
(function () {
  // evita inicializar duas vezes (ex.: hot reload, imports múltiplos)
  if (window.__userMenuInited) return;
  window.__userMenuInited = true;

  const init = () => {
    const btn  = document.getElementById('user-menu-button');
    const menu = document.getElementById('user-dropdown');
    if (!btn || !menu) return;

    const items = () => menu.querySelectorAll('[role="menuitem"]');
    const open  = () => {
      menu.classList.remove('hidden');
      btn.setAttribute('aria-expanded', 'true');
      items()[0]?.focus({ preventScroll: true });
    };
    const close = () => {
      if (!menu.classList.contains('hidden')) {
        menu.classList.add('hidden');
        btn.setAttribute('aria-expanded', 'false');
        btn.focus({ preventScroll: true });
      }
    };
    const toggle = () => (menu.classList.contains('hidden') ? open() : close());

    // abrir/fechar
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation(); // impede o clique-fora de disparar no bubbling
      toggle();
    });

    // fechar ao clicar fora
    document.addEventListener('click', (e) => {
      if (!menu.classList.contains('hidden') &&
          !menu.contains(e.target) &&
          !btn.contains(e.target)) {
        close();
      }
    });

    // fechar com Esc
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') close();
    });

    // navegação por teclado dentro do menu
    menu.addEventListener('keydown', (e) => {
      const list = Array.from(items());
      const i = list.indexOf(document.activeElement);
      if (e.key === 'Escape') return close();
      if (e.key === 'ArrowDown') { e.preventDefault(); (list[(i + 1) % list.length] || list[0])?.focus(); }
      if (e.key === 'ArrowUp')   { e.preventDefault(); (list[(i - 1 + list.length) % list.length] || list.at(-1))?.focus(); }
      if (e.key === 'Tab') {
        if ((!e.shiftKey && i === list.length - 1) || (e.shiftKey && i === 0)) close();
      }
    });
  };

  // corre já se o DOM estiver pronto; caso contrário espera pelo evento
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();
