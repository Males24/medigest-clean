document.addEventListener('DOMContentLoaded', () => {
  const el1 = document.querySelector('#chart-by-day');
  const el2 = document.querySelector('#chart-status');
  const el3 = document.querySelector('#chart-esps');
  if (!el1 || !el2 || !el3) return;

  const startEl = document.getElementById('dashStart');
  const endEl   = document.getElementById('dashEnd');

  // === Verde médico (brand) ===
  const BRAND = '#00795C';   // principal
  const BRAND_LT = '#00A37A'; // apoio (donut/agendada)

  // Paleta por estado para o donut
  const STATUS_COLORS = {
    confirmada:      BRAND,
    confirmado:      BRAND,
    agendada:        BRAND_LT,
    pendente:        '#F59E0B',
    pendente_medico: '#A855F7',
    cancelada:       '#EF4444',
    cancelado:       '#EF4444',
    default:         '#6B7280',
  };

  // Período por defeito: -30 a +30 dias
  const today   = new Date();
  const minus30 = new Date(today); minus30.setDate(today.getDate() - 30);
  const plus30  = new Date(today); plus30.setDate(today.getDate() + 30);
  startEl.value = minus30.toISOString().slice(0,10);
  endEl.value   = plus30.toISOString().slice(0,10);

  let c1, c2, c3;

  async function load() {
    try {
      const url = new URL(`${location.origin}/admin/dashboard/charts`);
      url.searchParams.set('start', startEl.value);
      url.searchParams.set('end',   endEl.value);

      const res = await fetch(url, { headers: { 'Accept':'application/json' }});
      const data = await res.json();

      const noData = { text: 'Sem dados no período', align: 'center', verticalAlign: 'middle' };

      // Garante inteiros
      const seriesByDay = (data.byDay?.series || []).map(n => Number(n) || 0);
      const seriesEsp   = (data.byEspecialidade?.series || []).map(n => Number(n) || 0);

      // Y em inteiros
      const yInt = {
        labels: { formatter: (v) => Number.isFinite(v) ? Math.round(v).toString() : '' },
        min: 0,
        forceNiceScale: true
      };
      const tooltipInt   = { y: { formatter: (v) => Math.round(v) } };
      const dataLabelInt = { enabled: false, formatter: (v) => Math.round(v) };

      // --- Área: consultas por dia ---
      const opt1 = {
        chart: { type:'area', height: 320, toolbar:{show:false} },
        noData,
        colors: [BRAND],
        series: [{ name:'Consultas', data: seriesByDay }],
        xaxis: { categories: data.byDay.labels },
        yaxis: yInt,
        dataLabels: dataLabelInt,
        stroke: { curve:'smooth', width:2, colors:[BRAND] },
        fill: {
          type:'gradient',
          gradient: { shadeIntensity: 0, opacityFrom: .30, opacityTo: .06, stops:[0,100] },
          colors: [BRAND]
        },
        markers: { size: 0, colors:[BRAND], strokeColors:[BRAND] },
        tooltip: tooltipInt,
      };

      // --- Donut: estados ---
      const donutColors = (data.status.labels || []).map(
        s => STATUS_COLORS[(s || '').toLowerCase()] || STATUS_COLORS.default
      );
      const opt2 = {
        chart: { type:'donut', height: 320 },
        noData,
        labels: data.status.labels,
        series: (data.status.series || []).map(n => Number(n) || 0),
        colors: donutColors,
        legend: { position:'bottom' },
        dataLabels: { enabled: true },
        tooltip: tooltipInt,
      };

      // --- Barras: especialidades ---
      const opt3 = {
        chart: { type:'bar', height: 360, toolbar:{show:false} },
        noData,
        colors: [BRAND],
        series: [{ name:'Consultas', data: seriesEsp }],
        xaxis: { categories: data.byEspecialidade.labels },
        yaxis: yInt,
        plotOptions: { bar: { borderRadius: 8, columnWidth: '45%' } },
        dataLabels: dataLabelInt,
        tooltip: tooltipInt,
      };

      if (c1) c1.destroy(); if (c2) c2.destroy(); if (c3) c3.destroy();
      c1 = new ApexCharts(el1, opt1); c1.render();
      c2 = new ApexCharts(el2, opt2); c2.render();
      c3 = new ApexCharts(el3, opt3); c3.render();
    } catch (e) {
      console.error('Erro ao carregar gráficos do dashboard:', e);
    }
  }

  startEl.addEventListener('change', load);
  endEl.addEventListener('change', load);
  load();
});
