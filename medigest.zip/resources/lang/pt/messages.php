<?php

return [

    // Nome da app e idiomas disponíveis
    'app' => [
        'name' => 'MediGest+',
        'locale_names' => [
            'pt' => 'Português (PT)',
            'en' => 'English',
            'es' => 'Español',
        ],
    ],

    // Itens de navegação (sidebar / header)
    'nav' => [
        'dashboard'          => 'Dashboard',
        'all_consultations'  => 'Todas as Consultas',
        'specialties'        => 'Especialidades',
        'create_doctor'      => 'Criar Médico',
        'schedules'          => 'Horários',
        'profile'            => 'Perfil',
        'settings'           => 'Configurações',
        'logout'             => 'Terminar sessão',
        'back'               => 'Voltar',
    ],

    // Ações comuns
    'actions' => [
        'save_changes'       => 'Guardar alterações',
        'save_preferences'   => 'Guardar preferências',
        'update_password'    => 'Atualizar password',
        'new_consultation'   => 'Nova Consulta',
        'cancel'             => 'Cancelar',
        'confirm'            => 'Confirmar',
        'edit'               => 'Editar',
        'delete'             => 'Eliminar',
        'search'             => 'Pesquisar',
        'apply'              => 'Aplicar',
        'close'              => 'Fechar',
        'change_photo'       => 'Alterar foto',
        'remove_photo'       => 'Remover foto',
    ],

    // Perfil
    'profile' => [
        'title'              => 'Perfil',
        'subtitle'           => 'Gerir informação pessoal e segurança da conta.',
        'name'               => 'Nome',
        'email'              => 'Email',
        'phone'              => 'Telefone',
        'role'               => 'Função',
        'photo_hint'         => 'PNG/JPG/WebP, até 2MB.',
        'security'           => 'Segurança',
        'password_new'       => 'Nova password',
        'password_confirm'   => 'Confirmar nova password',
        'strength'           => 'Força',
        'updated'            => 'Perfil atualizado com sucesso.',
        'password_updated'   => 'Password atualizada com sucesso.',
    ],

    // Configurações
    'settings' => [
        'title'              => 'Configurações',
        'subtitle'           => 'Preferências de interface, idioma e notificações.',
        'interface'          => 'Interface',
        'theme'              => 'Tema',
        'themes'             => [
            'light'  => 'Claro',
            'dark'   => 'Escuro',
            'system' => 'Automático',
        ],
        'language'           => 'Idioma',
        'notifications'      => 'Notificações',
        'notify_email'       => 'Email',
        'notify_email_hint'  => 'Receber alertas e confirmações por email.',
        'notify_push'        => 'Push',
        'notify_push_hint'   => 'Notificações do navegador (quando permitido).',
        'weekly_digest'      => 'Resumo semanal',
        'weekly_digest_hint' => 'Estatísticas e destaques da semana.',
        'saved'              => 'Preferências guardadas.',
    ],

    // Dashboard / Gráficos
    'dashboard' => [
        'by_day'             => 'Consultas por dia',
        'status'             => 'Estados das consultas',
        'by_specialty'       => 'Consultas por especialidade',
        'no_data'            => 'Sem dados no período',
        'period'             => 'Período',
        'from'               => 'de',
        'to'                 => 'até',
        'daily_total'        => 'Total diário no período.',
    ],

    // Consultas
    'consultas' => [
        'list_title'         => 'Consultas',
        'list_subtitle'      => 'Lista de todas as consultas registadas no sistema.',
        'patient'            => 'Paciente',
        'doctor'             => 'Médico',
        'specialty'          => 'Especialidade',
        'date'               => 'Data',
        'time'               => 'Hora',
        'status'             => 'Estado',
        'actions'            => 'Ações',
        'create_title'       => 'Criar Consulta',
        'create_subtitle'    => 'Preenche os passos para agendar a consulta.',
        'type'               => 'Tipo',
        'description'        => 'Descrição',
        'availability'       => 'Disponibilidade',
        'review'             => 'Revisão',
        'schedule'           => 'Agendar',
    ],

    // Estados de consulta
    'status' => [
        'scheduled'          => 'agendada',
        'confirmed'          => 'confirmada',
        'pending'            => 'pendente',
        'pending_doctor'     => 'pendente_medico',
        'canceled'           => 'cancelada',
    ],

    // Textos genéricos
    'common' => [
        'yes'                => 'Sim',
        'no'                 => 'Não',
        'none'               => '—',
        'loading'            => 'A carregar…',
        'error'              => 'Ocorreu um erro.',
        'success'            => 'Operação concluída com sucesso.',
    ],
];
