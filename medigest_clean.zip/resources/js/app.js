import './bootstrap';
import 'flowbite';
import './layout/user-menu.js';
import './layout/sidebar.js';
import './layout/navbar-paciente.js';

import Alpine from 'alpinejs';

window.Alpine = Alpine;
Alpine.start();