import './bootstrap';
import 'flowbite';
import './layout/dropdownMenu';

import Alpine from 'alpinejs';

window.Alpine = Alpine;
Alpine.start();