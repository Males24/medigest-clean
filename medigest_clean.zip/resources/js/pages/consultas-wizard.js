document.addEventListener('DOMContentLoaded', () => {
  const mount = document.querySelector('[data-page="wizard-consulta"]');
  if (!mount) return;

  const heads = [...document.querySelectorAll('.step-head')];
  const steps = [...document.querySelectorAll('.wizard-step')];

  const back   = document.getElementById('btnBack');
  const next   = document.getElementById('btnNext');
  const submit = document.getElementById('btnSubmit');

  const pacienteSel = document.getElementById('paciente_id');
  const tipoSel     = document.getElementById('tipo');
  const dataEl      = document.getElementById('data');
  const horaSel     = document.getElementById('hora');
  const durSel      = document.getElementById('duracao');
  const motivoEl    = document.getElementById('motivo');
  const slotsMsg    = document.getElementById('slotsMsg');

  let i = 0;

  const setHead = (idx) => {
    heads.forEach((h, n) => {
      h.classList.toggle('text-home-medigest', n <= idx);
      h.classList.toggle('font-semibold', n <= idx);
    });
  };

  const show = (idx) => {
    i = idx;
    steps.forEach((s, n) => s.classList.toggle('hidden', n !== i));
    setHead(i);
    back.disabled = i === 0;
    next.classList.toggle('hidden', i === steps.length - 1);
    submit.classList.toggle('hidden', i !== steps.length - 1);
    if (i === 2) loadSlots();
    if (i === steps.length - 1) fillReview();
  };

  const valid = (idx) => {
    switch (idx) {
      case 0: return !!pacienteSel.value;
      case 1: return !!tipoSel.value;
      case 2: return !!dataEl.value && !!horaSel.value;
      case 3: return !!durSel.value;
      default: return true;
    }
  };

  back.addEventListener('click', () => show(Math.max(0, i - 1)));
  next.addEventListener('click', () => {
    if (!valid(i)) return nudge();
    show(Math.min(steps.length - 1, i + 1));
  });

  function nudge() {
    const s = steps[i];
    s.classList.add('animate-pulse');
    setTimeout(() => s.classList.remove('animate-pulse'), 200);
  }

  async function loadSlots() {
    if (!dataEl.value) {
      setHourOptions([], '— seleciona data —'); return;
    }
    try {
      const params = new URLSearchParams({
        data: dataEl.value,
        duracao: durSel.value || '30',
        tipo: tipoSel.value || 'normal'
      });
      const res = await fetch(`/medico/slots?${params.toString()}`, { headers: { 'Accept':'application/json' }});
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const slots = await res.json();
      setHourOptions(Array.isArray(slots) ? slots : []);
      slotsMsg.textContent = slots.length
        ? `${slots.length} horários disponíveis`
        : 'Sem disponibilidade para a data escolhida';
    } catch (e) {
      console.error(e);
      setHourOptions([], 'Erro ao carregar slots');
      slotsMsg.textContent = 'Erro ao carregar slots';
    }
  }

  function setHourOptions(slots, placeholder='Sem disponibilidade') {
    horaSel.innerHTML = '';
    if (!slots.length) {
      const opt = document.createElement('option');
      opt.value = ''; opt.textContent = placeholder;
      horaSel.appendChild(opt); return;
    }
    slots.forEach(h => {
      const opt = document.createElement('option');
      opt.value = h; opt.textContent = h;
      horaSel.appendChild(opt);
    });
  }

  [dataEl, durSel, tipoSel].forEach(el =>
    el.addEventListener('change', () => { if (i === 2) loadSlots(); })
  );

  function fillReview(){
    const pacTxt = pacienteSel.options[pacienteSel.selectedIndex]?.text || '';
    mount.querySelector('[data-review="paciente"]').textContent = pacTxt;
    mount.querySelector('[data-review="tipo"]').textContent = tipoSel.value;
    mount.querySelector('[data-review="data"]').textContent = dataEl.value || '';
    mount.querySelector('[data-review="hora"]').textContent = horaSel.value || '';
    mount.querySelector('[data-review="duracao"]').textContent = durSel.value || '';
    mount.querySelector('[data-review="motivo"]').textContent = motivoEl.value || '—';
  }

  show(0);
});
