// resources/js/pages/consultas-admin-wizard.js
document.addEventListener('DOMContentLoaded', () => {
  const mount = document.querySelector('[data-page="wizard-consulta-admin"]');
  if (!mount) return;

  const heads   = [...document.querySelectorAll('.step-head')];
  const steps   = [...document.querySelectorAll('.wizard-step')];
  const back    = document.getElementById('btnBack');
  const next    = document.getElementById('btnNext');
  const submit  = document.getElementById('btnSubmit');

  const pacienteSel = document.getElementById('paciente_id');
  const espSel      = document.getElementById('especialidade_id');
  const medicoSel   = document.getElementById('medico_id');
  const tipoSel     = document.getElementById('tipo');
  const dataEl      = document.getElementById('data');       // hidden YYYY-MM-DD
  const horaSel     = document.getElementById('hora');
  const durSel      = document.getElementById('duracao');
  const motivoEl    = document.getElementById('motivo');
  const slotsMsg    = document.getElementById('slotsMsg');

  let i = 0;

  const setHead = (idx) => {
    heads.forEach((h, n) => {
      h.classList.toggle('text-home-medigest', n <= idx);
      h.classList.toggle('font-semibold', n <= idx);
    });
  };

  const show = (idx) => {
    i = idx;
    steps.forEach((s, n) => s.classList.toggle('hidden', n !== i));
    setHead(i);

    if (back) {
      back.style.visibility = i < 1 ? 'hidden' : 'visible';
      back.disabled = i < 1;
    }

    next.classList.toggle('hidden', i === steps.length - 1);
    submit.classList.toggle('hidden', i !== steps.length - 1);

    if (i === 4) loadSlots();
    if (i === steps.length - 1) fillReview();
  };

  const valid = (idx) => {
    switch (idx) {
      case 0: return !!pacienteSel?.value;
      case 1: return !!espSel?.value;
      case 2: return !!medicoSel?.value;
      case 3: return !!(tipoSel?.value || 'normal');
      case 4: return !!dataEl?.value && !!horaSel?.value;
      case 5: return !!durSel?.value;
      default: return true;
    }
  };

  back?.addEventListener('click', () => show(Math.max(0, i - 1)));
  next?.addEventListener('click', () => {
    if (!valid(i)) return nudge();
    show(Math.min(steps.length - 1, i + 1));
  });

  function nudge() {
    const s = steps[i];
    s.classList.add('animate-pulse');
    setTimeout(() => s.classList.remove('animate-pulse'), 200);
  }

  // Filtrar médicos por especialidade
  espSel?.addEventListener('change', async () => {
    if (!espSel.value) return setMedicosOptions([]);
    try {
      const res = await fetch(`/admin/especialidades/${espSel.value}/medicos`, { headers: { Accept: 'application/json' } });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const medicos = await res.json();
      setMedicosOptions(medicos);
    } catch (e) {
      console.error(e);
      setMedicosOptions([]);
    }
  });

  function setMedicosOptions(medicos) {
    medicoSel.innerHTML = '';
    const placeholder = document.createElement('option');
    placeholder.value = '';
    placeholder.textContent = medicos.length ? '— seleciona —' : 'Sem médicos para esta especialidade';
    medicoSel.appendChild(placeholder);

    medicos.forEach(m => {
      const opt = document.createElement('option');
      opt.value = m.id;
      opt.textContent = `${m.name} — ${m.email}`;
      medicoSel.appendChild(opt);
    });
  }

  async function loadSlots() {
    if (!medicoSel?.value || !dataEl?.value) {
      setHourOptions([], '— seleciona médico e data —');
      return;
    }
    try {
      const params = new URLSearchParams({
        medico_id: medicoSel.value,
        data: dataEl.value,
        duracao: durSel?.value || '30',
        tipo: (tipoSel?.value || 'normal')
      });
      const res = await fetch(`/admin/slots?${params.toString()}`, { headers: { Accept: 'application/json' } });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const slots = await res.json();
      setHourOptions(Array.isArray(slots) ? slots : []);
      if (slotsMsg) {
        slotsMsg.textContent = slots.length
          ? `${slots.length} horários disponíveis`
          : 'Sem disponibilidade para a data escolhida';
      }
    } catch (e) {
      console.error(e);
      setHourOptions([], 'Erro ao carregar slots');
      if (slotsMsg) slotsMsg.textContent = 'Erro ao carregar slots';
    }
  }

  function setHourOptions(slots, placeholder = 'Sem disponibilidade') {
    horaSel.innerHTML = '';
    if (!slots.length) {
      const opt = document.createElement('option');
      opt.value = '';
      opt.textContent = placeholder;
      horaSel.appendChild(opt);
      return;
    }
    slots.forEach((h) => {
      const opt = document.createElement('option');
      opt.value = h;
      opt.textContent = h;
      horaSel.appendChild(opt);
    });
  }

  // quando a data do datepicker mudar (evento disparado no ficheiro do datepicker)
  document.addEventListener('wizard:dataChanged', () => { if (i === 4) loadSlots(); });

  [durSel, medicoSel, tipoSel].forEach((el) =>
    el?.addEventListener('change', () => { if (i === 4) loadSlots(); })
  );

  function fillReview() {
    const pacTxt = pacienteSel?.options[pacienteSel.selectedIndex]?.text || '';
    const espTxt = espSel?.options[espSel.selectedIndex]?.text || '';
    const medTxt = medicoSel?.options[medicoSel.selectedIndex]?.text || '';

    mount.querySelector('[data-review="paciente"]').textContent = pacTxt;
    const espNode = mount.querySelector('[data-review="especialidade"]');
    if (espNode) espNode.textContent = espTxt;
    mount.querySelector('[data-review="medico"]').textContent = medTxt;

    mount.querySelector('[data-review="tipo"]').textContent = tipoSel?.value || 'normal';
    mount.querySelector('[data-review="data"]').textContent = dataEl?.value || '';
    mount.querySelector('[data-review="hora"]').textContent = horaSel?.value || '';
    mount.querySelector('[data-review="duracao"]').textContent = durSel?.value || '';
    mount.querySelector('[data-review="motivo"]').textContent = motivoEl?.value || '—';
  }

  show(0);
});
