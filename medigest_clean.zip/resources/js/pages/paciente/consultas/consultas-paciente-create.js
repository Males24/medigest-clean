// Wizard paciente com visual/UX do admin (rails + ícones + legendas)
document.addEventListener('DOMContentLoaded', () => {
  const $  = (s,ctx=document)=>ctx.querySelector(s);
  const $$ = (s,ctx=document)=>Array.from(ctx.querySelectorAll(s));

  const mount = document.querySelector('[data-page="wizard-consulta-paciente"]');
  if (!mount) return;

  // Endpoints/metas
  const slotsURL    = document.querySelector('meta[name="api-slots"]')?.content || '/api/slots';
  const medicosTmpl = document.querySelector('meta[name="api-medicos-template"]')?.content || '/api/especialidades/{id}/medicos';

  // Preferências
  const qs = new URLSearchParams(location.search);
  const prefEsp = document.querySelector('meta[name="pref-esp"]')?.content || qs.get('especialidade') || qs.get('especialidade_id') || '';
  const prefMed = document.querySelector('meta[name="pref-med"]')?.content || qs.get('medico') || qs.get('medico_id') || '';

  // Campos
  const espSel   = $('#especialidade_id');
  const medSel   = $('#medico_id');
  const tipoSel  = $('#tipo_slug');
  const dataEl   = $('#data');
  const horaSel  = $('#hora');
  const chipsBox = $('#slotChips');
  const slotsMsg = $('#slotsMsg') || $('#slotStatus');

  // UI wizard
  const heads   = $$('#wizard-steps .step-head');
  const steps   = $$('.wiz-step');
  const rail    = $('#wizard-rail');
  const railFill= $('#wizard-rail-fill');

  const lbl     = $('#stepLabel');
  const back    = $('#btnBack');
  const next    = $('#btnNext');
  const submit  = $('#btnSubmit');
  let i = 0;

  /* ===== Selects ===== */
  (function enhanceSelects(){
    function build(select){
      if (!select || select.__mg) return;
      select.classList.add('sr-only','absolute','opacity-0','-z-10');
      const wrap = document.createElement('div');
      wrap.className = 'relative w-full';
      select.parentNode.insertBefore(wrap, select);
      wrap.appendChild(select);

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'mg-sel-btn w-full h-11 px-3.5 pe-10 text-left text-sm rounded-xl bg-white border border-zinc-300 ring-1 ring-transparent hover:bg-zinc-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition';
      wrap.appendChild(btn);

      const caret = document.createElement('span');
      caret.innerHTML = '<svg class="w-4 h-4" viewBox="0 0 20 20" fill="currentColor"><path d="M5.25 7.5l4.5 4.5 4.5-4.5"/></svg>';
      caret.className = 'pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-500';
      wrap.appendChild(caret);

      const menu = document.createElement('div');
      menu.className = 'mg-sel-menu hidden absolute z-50 mt-1 w-full rounded-xl border border-zinc-200 bg-white shadow-lg';
      menu.setAttribute('role','listbox');
      wrap.appendChild(menu);

      const searchBox = document.createElement('div');
      searchBox.className = 'p-2 border-b border-zinc-100';
      searchBox.innerHTML = '<input type="search" placeholder="Pesquisar…" class="w-full h-9 px-3 rounded-lg border border-zinc-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/40"/>';
      menu.appendChild(searchBox);
      const searchInput = searchBox.querySelector('input');

      const list = document.createElement('ul');
      list.className = 'max-h-64 overflow-auto py-1';
      menu.appendChild(list);

      function renderOptions(filter=''){
        list.innerHTML = '';
        const term = filter.trim().toLowerCase();
        Array.from(select.options).forEach(opt => {
          const li = document.createElement('li');
          const bo = document.createElement('button');
          bo.type = 'button';
          bo.className = 'w-full text-left px-3 py-2 text-sm hover:bg-zinc-50 flex items-center justify-between';
          bo.dataset.value = opt.value;
          if (opt.value === '') bo.classList.add('text-zinc-500');
          const match = opt.textContent.toLowerCase().includes(term);
          if (term && !match) li.style.display = 'none';
          bo.innerHTML = `<span class="truncate">${opt.textContent}</span>${opt.selected ? '<svg class="w-4 h-4 text-emerald-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M20 6L9 17l-5-5"/></svg>' : ''}`;
          bo.addEventListener('click', () => {
            select.value = opt.value;
            Array.from(select.options).forEach(o => (o.selected = (o.value === opt.value)));
            updateLabel(); close();
            select.dispatchEvent(new Event('change',{bubbles:true}));
          });
          li.appendChild(bo);
          list.appendChild(li);
        });
      }
      function updateLabel(){
        const opt = select.options[select.selectedIndex];
        btn.textContent = opt?.textContent || (select.options[0]?.textContent ?? '—');
        if (!opt || opt.value === '') btn.classList.add('text-zinc-500'); else btn.classList.remove('text-zinc-500');
      }
      function open(){ menu.classList.remove('hidden'); btn.setAttribute('aria-expanded','true'); searchInput.value=''; renderOptions(); setTimeout(()=>searchInput.focus(),0); document.addEventListener('click', onDoc); document.addEventListener('keydown', onKey); }
      function close(){ menu.classList.add('hidden');   btn.setAttribute('aria-expanded','false'); document.removeEventListener('click', onDoc); document.removeEventListener('keydown', onKey); }
      function onDoc(e){ if (!wrap.contains(e.target)) close(); }
      function onKey(e){ if (e.key === 'Escape') { e.preventDefault(); close(); btn.focus(); } }

      btn.addEventListener('click', ()=> (btn.getAttribute('aria-expanded')==='true'?close():open()));
      searchInput.addEventListener('input', ()=>renderOptions(searchInput.value));

      updateLabel(); renderOptions();
      select.__mg = { refresh(){ renderOptions(); updateLabel(); } };
    }
    document.querySelectorAll('select[data-mg-select]').forEach(build);
    window.__refreshMgSelect = (sel) => { if (sel && sel.__mg) sel.__mg.refresh(); };
  })();

  /* ===== Helpers ===== */
  const fmtISO = d => d.toISOString().slice(0,10);
  const addDays = (d,n)=>{ const x=new Date(d); x.setDate(x.getDate()+n); return x; };
  const monthsPT=['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];

  /* ===== Step heads ===== */
  function paintHead(li, state){
    const circle = li.querySelector('.step-circle');
    const ico    = li.querySelector('.step-ico');
    const check  = li.querySelector('.step-check');

    circle.className = 'step-circle';
    circle.classList.add('bg-white','border','border-gray-300','text-gray-600');
    ico.classList.remove('hidden'); check.classList.add('hidden');

    if (state==='done'){
      circle.classList.remove('bg-white','border-gray-300','text-gray-600');
      circle.classList.add('bg-emerald-600','border-emerald-600','text-white');
      ico.classList.add('hidden'); check.classList.remove('hidden');
      li.classList.add('done'); li.classList.remove('current');
    } else if (state==='current'){
      circle.classList.add('ring-2','ring-emerald-400/60','border-emerald-400','text-emerald-700');
      li.classList.add('current'); li.classList.remove('done');
    } else {
      li.classList.remove('done','current');
    }
  }
  function setHead(idx){
    heads.forEach((h,n)=>{
      if (n<idx) paintHead(h,'done');
      else if (n===idx) paintHead(h,'current');
      else paintHead(h,'todo');
    });
  }
  function updateRail(){
    if (!rail || !railFill || !heads.length) return;
    const active = heads[i] || heads[0];
    const railRect = rail.getBoundingClientRect();
    const liRect   = active.getBoundingClientRect();
    const center   = liRect.left + liRect.width/2 - railRect.left;
    const width    = Math.max(0, Math.min(railRect.width, center));
    railFill.style.width = width + 'px';
  }
  function maxUnlocked(){
    if(!espSel.value) return 0;
    if(!medSel.value) return 1;
    if(!tipoSel.value) return 2;
    if(!(dataEl.value && horaSel.value)) return 3;
    return 5;
  }
  function updateClickable(){
    const m = maxUnlocked();
    heads.forEach((li, idx) => {
      const clickable = idx <= m;
      li.classList.toggle('cursor-pointer', clickable);
      li.classList.toggle('pointer-events-none', !clickable);
      li.style.opacity = clickable ? 1 : 0.6;
    });
  }

  /* ===== Navegação (força display dos botões) ===== */
  function showBtn(el, show){ if (!el) return; el.style.display = show ? '' : 'none'; }
  async function show(idx){
    i = idx;
    steps.forEach((s,n)=>s.classList.toggle('hidden', n!==i));
    setHead(i); updateRail(); updateClickable();
    if (lbl) lbl.textContent = `Passo ${i+1} de ${steps.length}`;

    // Footer
    back.style.visibility = i===0 ? 'hidden' : 'visible';
    back.disabled = (i===0);
    showBtn(next,   i !== steps.length - 1);   // esconder no último passo
    showBtn(submit, i === steps.length - 1);   // mostrar só no último passo

    if (i===3) { await ensureMinDateFromTipo(true); renderCalendar(); loadSlots(); }
    if (i===5) fillReview();
  }
  function validate(idx){
    switch(idx){
      case 0: return !!espSel.value;
      case 1: return !!medSel.value;
      case 2: return !!tipoSel.value;
      case 3: return !!dataEl.value && !!horaSel.value;
      default: return true;
    }
  }
  function nudge(){ const s = steps[i]; s.classList.add('animate-pulse'); setTimeout(()=>s.classList.remove('animate-pulse'),200); }

  back?.addEventListener('click', ()=>{ show(Math.max(0, i-1)); });
  next?.addEventListener('click', ()=>{ if(!validate(i)) return nudge(); show(Math.min(steps.length-1, i+1)); });
  heads.forEach((li, idx) => li.addEventListener('click', ()=>{ if(idx<=maxUnlocked()) show(idx); else nudge(); }));
  window.addEventListener('resize', updateRail);

  /* ===== Médicos por especialidade ===== */
  async function loadMedicos(){
    horaSel.value=''; setSlotChips([]); if (slotsMsg) slotsMsg.textContent = 'Seleciona os campos';
    const id = espSel.value;
    if(!id){
      medSel.innerHTML='<option value="">Sem médicos</option>'; medSel.disabled=true;
      window.__refreshMgSelect?.(medSel); updateClickable(); return;
    }
    medSel.innerHTML = '<option value="">— a carregar… —</option>'; medSel.disabled = true; window.__refreshMgSelect?.(medSel);
    try{
      const url = medicosTmpl.replace('{id}', encodeURIComponent(id));
      const r   = await fetch(url, { headers:{ 'Accept':'application/json' } });
      const list= await r.json();
      medSel.innerHTML = '';
      if(!Array.isArray(list) || !list.length){
        medSel.innerHTML = '<option value="">Sem médicos</option>'; medSel.disabled=true; window.__refreshMgSelect?.(medSel); updateClickable(); return;
      }
      const ph = document.createElement('option'); ph.value=''; ph.textContent='— Seleciona —'; medSel.appendChild(ph);
      list.forEach(m=>{ const o=document.createElement('option'); o.value=m.id; o.textContent=`${m.name}${m.email?' — '+m.email:''}`; medSel.appendChild(o); });
      medSel.disabled=false; window.__refreshMgSelect?.(medSel);

      const wanted = String(prefMed || medSel.dataset.old || '');
      if (wanted) {
        const opt = Array.from(medSel.options).find(o => String(o.value) === wanted);
        if (opt) medSel.value = opt.value;
      }
    }catch(e){
      console.error(e);
      medSel.innerHTML = '<option value="">Erro ao carregar</option>'; medSel.disabled=true; window.__refreshMgSelect?.(medSel);
    } finally { updateClickable(); }
  }
  espSel?.addEventListener('change', loadMedicos);

  /* ===== Tipo/meta & datas ===== */
  async function fetchTipoMeta(slug){
    if (!slug) return null;
    try{
      const r = await fetch(`/api/consulta-tipos/${encodeURIComponent(slug)}`, { headers: { 'Accept':'application/json' }});
      if (!r.ok) return null;
      return await r.json();
    }catch{ return null; }
  }
  async function hasSlots(dateISO){
    if(!medSel.value || !tipoSel.value) return false;
    try{
      const url=new URL(slotsURL,window.location.origin);
      url.searchParams.set('medico_id', medSel.value);
      url.searchParams.set('data', dateISO);
      url.searchParams.set('tipo', tipoSel.value);
      url.searchParams.set('duracao', Number($('#duracao')?.value || 30));
      const r=await fetch(url,{headers:{'Accept':'application/json'}}); const j=await r.json();
      const arr = Array.isArray(j?.data) ? j.data : (Array.isArray(j) ? j : []);
      return arr.length>0;
    }catch{ return false; }
  }
  async function firstDayWithSlots(fromISO){
    let probe = fromISO;
    for(let k=0;k<60;k++){
      if(await hasSlots(probe)) return probe;
      probe = fmtISO(addDays(new Date(probe),1));
    }
    return fromISO;
  }
  async function ensureMinDateFromTipo(auto=false){
    const todayISO = fmtISO(new Date());
    let minISO = todayISO;

    const slug = tipoSel?.value;
    if (slug) {
      const meta = await fetchTipoMeta(slug);
      const lead = Number(meta?.lead_minutos ?? 0);
      const minStart = new Date(Date.now() + lead*60*1000);
      minISO = fmtISO(minStart);
    }
    if (medSel.value && tipoSel.value) minISO = await firstDayWithSlots(minISO);

    dataEl.dataset.min = minISO;
    const needsSet = !dataEl.value || dataEl.value < minISO;
    if (auto && needsSet) dataEl.value = minISO;

    const m = new Date(currentMonth);
    const min = new Date(minISO);
    if (m.getFullYear() < min.getFullYear() || (m.getFullYear()===min.getFullYear() && m.getMonth()<min.getMonth())) {
      currentMonth = new Date(min.getFullYear(), min.getMonth(), 1);
    }
  }

  /* ===== Slots ===== */
  function setSlotChips(slots, loading=false){
    chipsBox.innerHTML = '';
    if (loading) { chipsBox.innerHTML = '<div class="text-sm text-zinc-500 px-1">A carregar…</div>'; return; }
    if (!Array.isArray(slots) || !slots.length) { chipsBox.innerHTML = '<div class="text-sm text-zinc-500 px-1">Sem disponibilidade</div>'; return; }

    const wrap = document.createElement('div'); wrap.className='flex flex-wrap gap-2';
    slots.forEach(h=>{
      const b = document.createElement('button');
      b.type='button'; b.className='slot-chip'; b.textContent=h;
      // não pré-selecionar automaticamente
      if (horaSel.value===h) b.setAttribute('aria-pressed','true');
      b.addEventListener('click', ()=>{
        horaSel.value=h;
        wrap.querySelectorAll('.slot-chip').forEach(x=>x.setAttribute('aria-pressed','false'));
        b.setAttribute('aria-pressed','true');
      });
      wrap.appendChild(b);

      const o=document.createElement('option'); o.value=h; o.textContent=h; horaSel.appendChild(o);
    });
    chipsBox.appendChild(wrap);
  }
  async function loadSlots(){
    horaSel.innerHTML = '<option value="">—</option>';
    if(!(espSel.value && medSel.value && tipoSel.value && dataEl.value)){
      setSlotChips([]); if (slotsMsg) slotsMsg.textContent='Seleciona especialidade, médico, tipo e data'; return;
    }
    setSlotChips([], true); if (slotsMsg) slotsMsg.textContent='A carregar…';
    try{
      const url=new URL(slotsURL,window.location.origin);
      url.searchParams.set('medico_id', medSel.value);
      url.searchParams.set('data', dataEl.value);
      url.searchParams.set('tipo', tipoSel.value);
      url.searchParams.set('duracao', Number($('#duracao')?.value || 30));
      const r = await fetch(url, { headers:{ 'Accept':'application/json' }});
      const j = await r.json();
      const arr = Array.isArray(j?.data) ? j.data : (Array.isArray(j)? j : []);
      setSlotChips(arr);
      if (slotsMsg) slotsMsg.textContent = arr.length ? `${arr.length} horários disponíveis` : 'Sem disponibilidade';
    }catch(e){
      console.error(e);
      setSlotChips([]); if (slotsMsg) slotsMsg.textContent='Erro ao carregar slots';
    }
  }
  medSel?.addEventListener('change', async ()=>{ await ensureMinDateFromTipo(true); renderCalendar(); loadSlots(); });
  tipoSel?.addEventListener('change', async ()=>{ await ensureMinDateFromTipo(true); renderCalendar(); loadSlots(); });

  /* ===== Calendário ===== */
  let currentMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  const calTitle = $('#calTitle'), calGrid = $('#calGrid');
  function startOfGrid(d){ const first = new Date(d.getFullYear(), d.getMonth(), 1); const day = first.getDay(); const out = new Date(first); out.setDate(first.getDate()-day); return out; }
  function renderCalendar(){
    if (!calGrid) return;
    const minISO = dataEl.dataset.min || fmtISO(new Date());
    const minD = new Date(minISO);

    if (calTitle) calTitle.textContent = `${monthsPT[currentMonth.getMonth()]} ${currentMonth.getFullYear()}`;

    calGrid.innerHTML = '';
    const start = startOfGrid(currentMonth);
    const selectedISO = dataEl.value || '';
    for (let k=0;k<42;k++){
      const date = new Date(start); date.setDate(start.getDate()+k);
      const iso = fmtISO(date);
      const inMonth = date.getMonth()===currentMonth.getMonth();
      const disabled = date < minD;

      const btn = document.createElement('button');
      btn.type='button'; btn.dataset.date=iso;
      btn.className = 'w-full aspect-square rounded-lg text-sm flex items-center justify-center border ' +
        (disabled ? 'text-zinc-300 border-zinc-100 cursor-not-allowed bg-zinc-50' :
          (iso===selectedISO ? 'border-emerald-500 bg-emerald-50 ring-2 ring-emerald-500 text-emerald-800' :
            (inMonth ? 'border-zinc-200 hover:bg-zinc-50' : 'border-zinc-100 text-zinc-400 hover:bg-zinc-50')));
      btn.textContent = String(date.getDate());

      if (!disabled) btn.addEventListener('click', async ()=>{
        dataEl.value = iso;
        renderCalendar();
        await loadSlots();
      });
      calGrid.appendChild(btn);
    }
  }
  $('#calPrev')?.addEventListener('click', ()=>{ currentMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth()-1, 1); renderCalendar(); });
  $('#calNext')?.addEventListener('click', ()=>{ currentMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth()+1, 1); renderCalendar(); });

  /* ===== Revisão ===== */
  function fillReview(){
    const t = (sel)=> sel?.options?.[sel.selectedIndex]?.textContent || '';
    const set = (q,v)=>{ const el=$(q); if(el) el.textContent=v; };
    set('[data-review="esp"]',  t(espSel) || '—');
    set('[data-review="med"]',  t(medSel) || '—');
    set('[data-review="tipo"]', t(tipoSel) || '—');
    set('[data-review="data"]', dataEl?.value || '—');
    set('[data-review="hora"]', horaSel?.value || '—');
    set('[data-review="desc"]', $('#descricao')?.value || '—');
  }

  /* ===== Arranque ===== */
  const todayISO = fmtISO(new Date());
  dataEl.dataset.min = todayISO;
  if (!dataEl.value) dataEl.value = todayISO;

  if (prefEsp) espSel.value = String(prefEsp);
  window.__refreshMgSelect?.(espSel);

  if (espSel.value) {
    loadMedicos().then(async ()=>{
      if (prefMed) { medSel.value = String(prefMed); window.__refreshMgSelect?.(medSel); }
      await ensureMinDateFromTipo(true);
      renderCalendar();
      loadSlots();
    });
  } else {
    renderCalendar();
  }

  updateClickable();
  show(0); // garante footer correcto já no arranque
});
