// Modal de detalhe + confirmação de cancelamento (médico)
(function(){
  const t = (p, fb='') => p.split('.').reduce((o,k)=>o?.[k], (window.I18N||{})) ?? fb;

  function mkModal(html){
    const wrap = document.createElement('div');
    wrap.className = 'fixed inset-0 z-[10000]';
    wrap.innerHTML = `
      <div class="absolute inset-0 bg-black/40"></div>
      <div class="absolute inset-0 grid place-items-center p-4">
        <div class="max-w-lg w-full rounded-2xl bg-white shadow-xl ring-1 ring-gray-200 overflow-hidden">
          ${html}
        </div>
      </div>`;
    document.body.appendChild(wrap);
    wrap.addEventListener('click', (e)=>{ if(e.target===wrap || e.target.closest('[data-close]')) wrap.remove(); });
    window.addEventListener('keydown', onEsc);
    function onEsc(e){ if(e.key==='Escape'){ wrap.remove(); window.removeEventListener('keydown', onEsc);} }
    return wrap;
  }

  window.mostrarModalConsulta = (payload={}) => {
    const html = `
      <div class="px-5 py-4 bg-gradient-to-b from-gray-50 to-white border-b border-gray-100">
        <h3 class="text-lg font-semibold text-gray-900">${t('modals.consultation_details','Detalhes da consulta')}</h3>
      </div>
      <div class="p-5 space-y-3 text-sm">
        <div><span class="text-gray-500">${t('common.patient','Paciente')}:</span> <span class="font-medium text-gray-900">${payload.paciente_nome||'-'}</span></div>
        <div><span class="text-gray-500">${t('common.email','Email')}:</span> <span class="text-gray-900">${payload.paciente_email||'-'}</span></div>
        <div><span class="text-gray-500">${t('common.doctor','Médico')}:</span> <span class="text-gray-900">${payload.medico_nome||'-'}</span></div>
        <div><span class="text-gray-500">${t('common.specialty','Especialidade')}:</span> <span class="text-gray-900">${payload.especialidade_nome||'-'}</span></div>
        <div><span class="text-gray-500">${t('common.datetime','Data/Hora')}:</span> <span class="text-gray-900">${payload.data_consulta||'-'}</span></div>
        <div><span class="text-gray-500">${t('common.status','Estado')}:</span> <span class="text-gray-900">${payload.estado||'-'}</span></div>
        <div><span class="text-gray-500">${t('common.description','Descrição')}:</span><div class="text-gray-900 whitespace-pre-wrap">${payload.descricao||'-'}</div></div>
      </div>
      <div class="px-5 py-3 bg-gray-50 text-right">
        <button type="button" data-close
          class="inline-flex items-center px-4 py-2 rounded-xl text-slate-800 border border-white/50 ring-1 ring-gray-200/80 bg-gradient-to-b from-gray-50 to-gray-100 hover:from-white hover:to-gray-50">
          ${t('actions.close','Fechar')}
        </button>
      </div>`;
    mkModal(html);
  };

  window.confirmarCancelamento = ({ action, csrf }) => {
    const html = `
      <form method="POST" action="${action}">
        <input type="hidden" name="_token" value="${csrf}">
        <div class="px-5 py-4 bg-gradient-to-b from-rose-50 to-white border-b border-rose-100">
          <h3 class="text-lg font-semibold text-rose-700">${t('modals.confirm_cancel_title','Cancelar consulta?')}</h3>
        </div>
        <div class="p-5 text-sm text-gray-700">
          ${t('modals.confirm_cancel_text','Tem a certeza que pretende cancelar esta consulta?')}
        </div>
        <div class="px-5 py-3 bg-gray-50 flex items-center justify-end gap-2">
          <button type="button" data-close
            class="px-4 py-2 rounded-xl text-slate-800 border border-white/50 ring-1 ring-gray-200/80 bg-gradient-to-b from-gray-50 to-gray-100 hover:from-white hover:to-gray-50">
            ${t('actions.back','Voltar')}
          </button>
          <button type="submit"
            class="px-4 py-2 rounded-xl text-white bg-rose-600 hover:bg-rose-700 shadow-sm">
            ${t('actions.cancel','Cancelar')}
          </button>
        </div>
      </form>`;
    mkModal(html);
  };
})();
