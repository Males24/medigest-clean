// Filtro client-side por texto (paciente, especialidade, data, hora, estado)
document.addEventListener('DOMContentLoaded', () => {
  const input = document.getElementById('busca');
  const rows  = [...document.querySelectorAll('#t-consultas tbody [data-row]')];

  function norm(s){ return (s||'').toString().toLowerCase().normalize('NFD').replace(/\p{Diacritic}/gu,''); }

  function apply(){
    const q = norm(input.value);
    rows.forEach(tr => {
      const txt = [
        tr.querySelector('[data-col="paciente"]')?.textContent,
        tr.querySelector('[data-col="especialidade"]')?.textContent,
        tr.querySelector('[data-col="data"]')?.textContent,
        tr.querySelector('[data-col="hora"]')?.textContent,
        tr.querySelector('[data-col="estado"]')?.textContent,
      ].map(norm).join(' ');
      tr.style.display = q && !txt.includes(q) ? 'none' : '';
    });
  }
  input?.addEventListener('input', apply);
});
