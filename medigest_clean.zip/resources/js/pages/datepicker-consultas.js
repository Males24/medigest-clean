// resources/js/pages/datepicker-consultas.js

// JS do Flowbite (necessário para alguns helpers)
import 'flowbite/dist/flowbite.min.js';

// ⚠️ NÃO importar o CSS da lib: o pacote não exporta o ficheiro via "exports"
// import 'flowbite-datepicker/dist/flowbite-datepicker.css';

// Usa apenas os teus overrides de tema (podes editar cores aqui)
import '../../css/datepicker.css';

import Datepicker from 'flowbite-datepicker/Datepicker';

document.addEventListener('DOMContentLoaded', () => {
  const mount = document.querySelector('[data-page="wizard-consulta-admin"]');
  if (!mount) return;

  const visibleInput = document.getElementById('data_display');
  const hiddenInput  = document.getElementById('data');
  if (!visibleInput || !hiddenInput) return;

  // Locale PT-PT
  Datepicker.locales.pt = {
    days: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'],
    daysShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'],
    daysMin: ['Do','Se','Te','Qu','Qi','Se','Sa'],
    months: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
    monthsShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'],
    today: 'Hoje',
    clear: 'Limpar',
    titleFormat: 'MM yyyy',
  };

  const today = new Date();
  const max   = new Date();
  max.setDate(today.getDate() + 60);

  const dp = new Datepicker(visibleInput, {
    autohide: true,
    language: 'pt',
    format: 'dd/mm/yyyy',
    minDate: today,
    maxDate: max,
    todayBtn: true,
    clearBtn: true,
  });

  const toYmd = (d) => {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${dd}`;
  };

  visibleInput.addEventListener('changeDate', (ev) => {
    const d = ev.detail?.date;
    if (!d) return;
    hiddenInput.value = toYmd(d);
    document.dispatchEvent(new CustomEvent('wizard:dataChanged'));
  });

  // também suporta input manual dd/mm/yyyy
  visibleInput.addEventListener('change', () => {
    const [dd, mm, yyyy] = (visibleInput.value || '').split('/');
    const parsed = new Date(`${yyyy}-${mm}-${dd}T00:00:00`);
    if (!isNaN(parsed.getTime())) {
      dp.setDate(parsed, { render: true });
      hiddenInput.value = toYmd(parsed);
      document.dispatchEvent(new CustomEvent('wizard:dataChanged'));
    }
  });
});
