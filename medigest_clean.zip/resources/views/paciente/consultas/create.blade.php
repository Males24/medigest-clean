@extends('layouts.app')
@section('title', 'Nova consulta | MediGest+')

@php
  use Illuminate\Support\Facades\Route;

  $r = fn(string $name, array $params = [], string $fallback = '#')
      => Route::has($name) ? route($name, $params) : $fallback;

  $slotsUrl        = Route::has('api.slots') ? route('api.slots') : url('/api/slots');
  $medicosTemplate = url('/api/especialidades/{id}/medicos');

  $prefEsp = (int) request()->input('especialidade', request()->input('especialidade_id', old('especialidade_id')));
  $prefMed = (int) request()->input('medico',         request()->input('medico_id',         old('medico_id')));

  $stepLabels = ['Especialidade','Médico','Tipo','Data & hora','Descrição','Revisão'];
  $icons = [
    '<svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l4 8 8 1-6 6 1 9-7-4-7 4 1-9-6-6 8-1 4-8z"/></svg>',
    '<svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><rect x="3" y="7" width="18" height="13" rx="2"/><path d="M12 10v6M9 13h6"/></svg>',
    '<svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>',
    '<svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>',
    '<svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 8v5l3 3"/><circle cx="12" cy="12" r="10"/></svg>',
    '<svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 12l2 2 4-4"/></svg>',
  ];
@endphp

@push('head')
<style>
  .card{background:#fff;border:1px solid #e5e7eb;border-radius:1rem}
  .field{width:100%;height:44px;border:1px solid #d1d5db;border-radius:.75rem;padding:0 .8rem;background:#fff}
  .field:focus{outline:none;border-color:#10b981;box-shadow:0 0 0 2px rgba(16,185,129,.15)}
  .btn{display:inline-flex;align-items:center;justify-content:center;border-radius:.75rem;height:44px;padding:0 18px;font-weight:600}
  .btn-pri{background:#047857;color:#fff}.btn-pri:hover{background:#065f46}
  .btn-sec{background:#fff;border:1px solid #d1d5db}.btn-sec:hover{background:#f9fafb}
  .slot-chip{border:1px solid #e5e7eb;border-radius:.75rem;padding:.5rem .75rem;font-size:.875rem;background:#fff}
  .slot-chip[aria-pressed="true"]{border-color:#10b981;background:#ecfdf5;box-shadow:0 0 0 2px rgba(16,185,129,.35) inset}

  /* Step wizard (estilo admin) */
  #wizard-steps { scrollbar-width: none; -ms-overflow-style: none; overflow: visible; padding-block: .35rem; }
  #wizard-steps::-webkit-scrollbar { display: none; }
  .step-head .step-circle{width:48px;height:48px;border-radius:9999px;border:1px solid #e5e7eb;background:#fff;color:#475569;display:grid;place-items:center;box-shadow:0 1px 2px rgba(0,0,0,.04)}
  .step-head.done   .step-circle{background:#059669;border-color:#059669;color:#fff}
  .step-head.current .step-circle{outline:3px solid rgba(16,185,129,.25);border-color:#10b981;color:#047857}
  .step-caption{font-size:.72rem;color:#475569;margin-top:.35rem;text-align:center}
</style>
@endpush

@section('content')
  <x-ui.breadcrumbs :items="[
    ['label'=>'Início','url'=>route('home')],
    ['label'=>'Serviços','url'=>Route::has('paciente.consultas.index') ? route('paciente.consultas.index') : '#'],
    ['label'=>'Marcação de consultas','url'=>Route::has('paciente.consultas.index') ? route('paciente.consultas.index') : '#'],
    ['label'=>'Nova consulta']
  ]" />

  <x-ui.hero
    title="Nova consulta"
    subtitle="Siga os passos: especialidade, médico, tipo, data & hora e revisão."
    height="220px"
  />

  <section class="relative" data-page="wizard-consulta-paciente">
    <div class="pointer-events-none absolute inset-0 -z-10 bg-cover bg-center"
         style="background-image:linear-gradient(0deg, rgba(16,185,129,.18), rgba(16,185,129,.18)), url('{{ asset('/banner-medico-paciente.jpg') }}');filter:saturate(1.15) contrast(1.05) brightness(1.02);"></div>

    <meta name="api-slots" content="{{ $slotsUrl }}">
    <meta name="api-medicos-template" content="{{ $medicosTemplate }}">
    <meta name="pref-esp" content="{{ $prefEsp ?: '' }}">
    <meta name="pref-med" content="{{ $prefMed ?: '' }}">

    <div class="bg-zinc-50/40">
      <div class="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <form id="wizForm" method="POST" action="{{ $r('paciente.consultas.store') }}" class="card">
          @csrf

          {{-- Cabeçalho / stepper --}}
          <div class="p-5 sm:p-6">
            <div class="flex items-center justify-between mb-3">
              <h2 class="text-lg font-semibold text-zinc-900">Marcação em passos</h2>
              <span id="stepLabel" class="text-sm text-zinc-600">Passo 1 de 6</span>
            </div>

            <div id="wizard-rail" class="relative mb-2 pt-1 pb-2">
              <div class="absolute inset-x-0 top-1/2 -translate-y-1/2 h-1 bg-gray-200 rounded-full"></div>
              <div id="wizard-rail-fill" class="absolute left-0 top-1/2 -translate-y-1/2 h-1 bg-emerald-500 rounded-full transition-all duration-500" style="width:0"></div>

              <ol id="wizard-steps" class="relative flex items-start gap-6 flex-wrap md:flex-nowrap">
                @foreach($stepLabels as $i => $lbl)
                  <li class="step-head relative flex flex-col items-center md:flex-1" data-step-index="{{ $i }}">
                    <div class="step-circle">
                      <span class="step-ico">{!! $icons[$i] !!}</span>
                      <svg class="step-check w-6 h-6 hidden text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M20 6L9 17l-5-5"/></svg>
                    </div>
                    <div class="step-caption">{{ $lbl }}</div>
                  </li>
                @endforeach
              </ol>
            </div>
          </div>

          <hr class="border-zinc-200">

          {{-- Passos --}}
          <div class="p-5 sm:p-6 space-y-7">
            <section class="wiz-step" data-step="0">
              <h3 class="text-base font-medium text-zinc-900 mb-2">Escolha a especialidade</h3>
              <select id="especialidade_id" name="especialidade_id" class="field" data-mg-select required data-old="{{ old('especialidade_id', $prefEsp) }}">
                <option value="">— Selecionar —</option>
                @foreach(($especialidades ?? []) as $e)
                  <option value="{{ $e->id }}" {{ old('especialidade_id', $prefEsp)===$e->id?'selected':'' }}>{{ $e->nome }}</option>
                @endforeach
              </select>
              @error('especialidade_id')<p class="text-sm text-rose-600 mt-1">{{ $message }}</p>@enderror
            </section>

            <section class="wiz-step hidden" data-step="1">
              <h3 class="text-base font-medium text-zinc-900 mb-2">Selecione o médico</h3>
              <select id="medico_id" name="medico_id" class="field" data-mg-select required disabled data-old="{{ old('medico_id', $prefMed) }}">
                <option value="">— selecione a especialidade primeiro —</option>
              </select>
              @error('medico_id')<p class="text-sm text-rose-600 mt-1">{{ $message }}</p>@enderror
              <p class="text-xs text-zinc-500 mt-2">A lista é filtrada pela especialidade escolhida.</p>
            </section>

            <section class="wiz-step hidden" data-step="2">
              <h3 class="text-base font-medium text-zinc-900 mb-2">Tipo de consulta</h3>
              <select id="tipo_slug" name="tipo_slug" class="field" data-mg-select required>
                <option value="">— Selecionar —</option>
                <option value="normal"      {{ old('tipo_slug')==='normal'?'selected':'' }}>Normal</option>
                <option value="prioritaria" {{ old('tipo_slug')==='prioritaria'?'selected':'' }}>Prioritária</option>
                <option value="urgente"     {{ old('tipo_slug')==='urgente'?'selected':'' }}>Urgente</option>
              </select>
              @error('tipo_slug')<p class="text-sm text-rose-600 mt-1">{{ $message }}</p>@enderror
            </section>

            <section class="wiz-step hidden" data-step="3">
              <h3 class="text-base font-medium text-zinc-900 mb-2">Data & hora</h3>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label class="block text-sm font-medium text-zinc-800">Data</label>
                  <input id="data" name="data" type="hidden" required>
                  <div id="date-cal" class="rounded-xl border border-zinc-200 bg-white p-3">
                    <div class="flex items-center justify-between px-1 py-1.5">
                      <button type="button" id="calPrev" class="inline-flex items-center justify-center w-8 h-8 rounded-lg hover:bg-zinc-100" aria-label="Mês anterior">
                        <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
                      </button>
                      <div id="calTitle" class="text-sm font-medium text-zinc-900">—</div>
                      <button type="button" id="calNext" class="inline-flex items-center justify-center w-8 h-8 rounded-lg hover:bg-zinc-100" aria-label="Mês seguinte">
                        <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 6l6 6-6 6"/></svg>
                      </button>
                    </div>
                    <div class="mt-2 grid grid-cols-7 text-[11px] font-medium text-zinc-500">
                      <div class="text-center py-1">S</div><div class="text-center py-1">T</div><div class="text-center py-1">Q</div>
                      <div class="text-center py-1">Q</div><div class="text-center py-1">S</div><div class="text-center py-1">S</div><div class="text-center py-1">D</div>
                    </div>
                    <div id="calGrid" class="mt-1 grid grid-cols-7 gap-1.5"></div>
                  </div>
                </div>

                <div>
                  <div class="flex items-center justify-between">
                    <label class="block text-sm font-medium text-zinc-800">Hora</label>
                    <small id="slotStatus" class="text-xs text-zinc-500">—</small>
                  </div>
                  <select id="hora" name="hora" class="hidden" required><option value="">—</option></select>
                  <div id="slotChips" class="mt-1 min-h-[44px] rounded-xl border border-zinc-200 bg-white p-2">
                    <div class="text-sm text-zinc-500 px-1">Selecione especialidade, médico, tipo e data…</div>
                  </div>
                  <p id="slotsMsg" class="text-xs text-zinc-500 mt-2">Seleciona médico, tipo e data.</p>
                  @error('hora')<p class="text-sm text-rose-600 mt-1">{{ $message }}</p>@enderror
                </div>
              </div>
              <input type="hidden" id="duracao" name="duracao" value="{{ old('duracao', 30) }}">
            </section>

            <section class="wiz-step hidden" data-step="4">
              <h3 class="text-base font-medium text-zinc-900 mb-2">Descrição (opcional)</h3>
              <textarea id="descricao" name="descricao" rows="5" maxlength="400" class="w-full border border-zinc-300 rounded-xl p-3 text-sm focus:border-emerald-600 focus:ring-emerald-600" placeholder="Explique brevemente o motivo da consulta…">{{ old('descricao') }}</textarea>
              @error('descricao')<p class="text-sm text-rose-600 mt-1">{{ $message }}</p>@enderror
              <p class="text-xs text-zinc-500 mt-1">Máx. 400 caracteres.</p>
            </section>

            <section class="wiz-step hidden" data-step="5">
              <h3 class="text-base font-medium text-zinc-900 mb-2">Revise antes de agendar</h3>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div class="rounded-xl border border-zinc-200 p-4"><div class="text-xs text-zinc-500">Especialidade</div><div class="font-medium text-zinc-900" data-review="esp">—</div></div>
                <div class="rounded-xl border border-zinc-200 p-4"><div class="text-xs text-zinc-500">Médico</div><div class="font-medium text-zinc-900" data-review="med">—</div></div>
                <div class="rounded-xl border border-zinc-200 p-4"><div class="text-xs text-zinc-500">Tipo</div><div class="font-medium text-zinc-900" data-review="tipo">—</div></div>
                <div class="rounded-xl border border-zinc-200 p-4"><div class="text-xs text-zinc-500">Data</div><div class="font-medium text-zinc-900" data-review="data">—</div></div>
                <div class="rounded-xl border border-zinc-200 p-4"><div class="text-xs text-zinc-500">Hora</div><div class="font-medium text-zinc-900" data-review="hora">—</div></div>
                <div class="md:col-span-2 rounded-xl border border-zinc-200 p-4"><div class="text-xs text-zinc-500">Descrição</div><div class="font-medium text-zinc-900 whitespace-pre-line" data-review="desc">—</div></div>
              </div>
            </section>
          </div>

          <hr class="border-zinc-200">

          {{-- Footer: sem cancelar; Next/Back e, só na revisão, Agendar --}}
          <div class="px-5 sm:px-6 py-4 bg-zinc-50 rounded-b-xl flex items-center justify-between">
            <button type="button" id="btnBack" class="btn btn-sec" style="visibility:hidden" disabled>Anterior</button>
            <div class="flex items-center gap-2">
              <button type="button" id="btnNext" class="btn btn-pri">Seguinte</button>
              <button type="submit" id="btnSubmit" class="btn btn-pri" style="display:none">Agendar</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </section>
@endsection

@push('body-end')
  @vite('resources/js/pages/paciente/consultas/consultas-paciente-create.js')
@endpush
