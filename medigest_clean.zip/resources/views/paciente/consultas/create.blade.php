@extends('layouts.app')

@section('title', 'Marcar Consulta')

@section('content')
<div class="max-w-xl mx-auto py-8">
    <h2 class="text-2xl font-semibold mb-6">Marcar Consulta</h2>

    <form action="{{ route('paciente.consultas.store') }}" method="POST" class="space-y-4">
        @csrf

        <div>
            <label class="block font-medium">Médico</label>
            <select name="medico_id" class="w-full rounded border-gray-300" required>
                @foreach ($medicos as $medico)
                    <option value="{{ $medico->id }}">{{ $medico->name }}</option>
                @endforeach
            </select>
        </div>

        <div class="flex gap-4">
            <div class="flex-1">
                <label class="block font-medium">Data</label>
                <input type="date" name="data" class="w-full rounded border-gray-300" required>
            </div>
            <div class="flex-1">
                <label class="block font-medium">Hora</label>
                <input type="time" name="hora" class="w-full rounded border-gray-300" required>
            </div>
        </div>

        <div>
            <label class="block font-medium">Duração (min)</label>
            <input type="number" name="duracao" min="15" max="120" value="30" class="w-full rounded border-gray-300" required>
        </div>

        <div>
            <label class="block font-medium">Motivo</label>
            <textarea name="motivo" rows="2" class="w-full rounded border-gray-300"></textarea>
        </div>

        <button type="submit" class="bg-home-medigest-button hover:bg-home-medigest-button-hover text-white px-6 py-2 rounded">Confirmar</button>
    </form>
</div>
@endsection
