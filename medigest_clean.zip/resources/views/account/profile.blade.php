@extends('layouts.dashboard')
@section('title','Perfil')

@php($user = $user ?? auth()->user())

@section('content')
<div class="max-w-[1430px] mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-10 space-y-6">

  {{-- Cabeçalho --}}
  <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
    <div>
      <h1 class="text-2xl sm:text-3xl font-semibold tracking-tight text-gray-900">Perfil</h1>
      <p class="text-sm text-gray-500 mt-1">Gerir informação pessoal e segurança da conta.</p>
    </div>
    <a href="javascript:history.back()"
       class="inline-flex items-center gap-2 text-gray-700 hover:text-gray-900 hover:underline">
      ← Voltar
    </a>
  </div>

  {{-- Mensagens --}}
  @if (session('success'))
    <div class="rounded-xl px-4 py-3 bg-emerald-50 text-emerald-800 ring-1 ring-emerald-200/60">
      {{ session('success') }}
    </div>
  @endif
  @if ($errors->any())
    <div class="rounded-xl px-4 py-3 bg-rose-50 text-rose-700 ring-1 ring-rose-200/60">
      <ul class="list-disc list-inside text-sm">
        @foreach ($errors->all() as $e)<li>{{ $e }}</li>@endforeach
      </ul>
    </div>
  @endif

  <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    {{-- Informações básicas + avatar --}}
    <form method="POST" action="{{ route('account.profile.update') }}" enctype="multipart/form-data"
          class="lg:col-span-2 bg-white rounded-2xl shadow-sm ring-1 ring-gray-200/60">
      @csrf @method('PUT')

      <div class="p-6 sm:p-8 space-y-6">
        <div class="flex items-center gap-5">
          @php
            $fallback = 'https://ui-avatars.com/api/?name=' . urlencode($user->name) . '&background=E5E7EB&color=00795C&bold=true&format=svg&size=128';
          @endphp
          <img id="avatarPreview" src="{{ $user->avatar_url ?? $fallback }}" alt="Avatar"
               class="w-20 h-20 rounded-full ring-1 ring-gray-200 shadow-sm object-cover">
          <div class="space-y-2">
            <label for="avatar"
                   class="inline-flex items-center gap-2 rounded-xl px-3 py-1.5 text-sm
                          text-slate-800 border border-white/50 ring-1 ring-gray-200/80
                          bg-gradient-to-b from-gray-50 to-gray-100
                          shadow-[inset_-2px_-2px_6px_rgba(255,255,255,0.95),inset_3px_3px_8px_rgba(15,23,42,0.10)]
                          hover:from-white hover:to-gray-50 hover:ring-gray-300/80 cursor-pointer">
              <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
              Alterar foto
            </label>
            <input id="avatar" name="avatar" type="file" class="hidden" accept="image/*">
            <p class="text-xs text-gray-500">PNG/JPG, até 2MB.</p>
          </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Nome</label>
            <input name="name" type="text" value="{{ old('name', $user->name) }}"
                   class="w-full rounded-xl border-gray-300 focus:border-emerald-600 focus:ring-emerald-600">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input name="email" type="email" value="{{ old('email', $user->email) }}"
                   class="w-full rounded-xl border-gray-300 focus:border-emerald-600 focus:ring-emerald-600">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Telefone</label>
            <input name="phone" type="tel" value="{{ old('phone', $user->phone ?? '') }}"
                   class="w-full rounded-xl border-gray-300 focus:border-emerald-600 focus:ring-emerald-600">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Função</label>
            <input type="text" value="{{ ucfirst($user->role) }}" disabled
                   class="w-full rounded-xl border-gray-200 bg-gray-50 text-gray-500">
          </div>
        </div>
      </div>

      <div class="px-6 sm:px-8 py-4 bg-gray-50 rounded-b-2xl flex items-center justify-end">
        <button type="submit"
                class="px-5 py-2.5 rounded-xl text-white bg-home-medigest hover:bg-home-medigest-hover">
          Guardar alterações
        </button>
      </div>
    </form>

    {{-- Segurança: password --}}
    <form method="POST" action="{{ route('account.password.update') }}"
          class="bg-white rounded-2xl shadow-sm ring-1 ring-gray-200/60">
      @csrf @method('PUT')

      <div class="p-6 sm:p-8 space-y-4">
        <h2 class="text-lg font-medium text-gray-900">Segurança</h2>
        <div class="space-y-3">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Password atual</label>
            <input name="current_password" type="password"
                   class="w-full rounded-xl border-gray-300 focus:border-emerald-600 focus:ring-emerald-600">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Nova password</label>
            <input name="password" type="password"
                   class="w-full rounded-xl border-gray-300 focus:border-emerald-600 focus:ring-emerald-600">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Confirmar nova password</label>
            <input name="password_confirmation" type="password"
                   class="w-full rounded-xl border-gray-300 focus:border-emerald-600 focus:ring-emerald-600">
          </div>
        </div>
      </div>

      <div class="px-6 sm:px-8 py-4 bg-gray-50 rounded-b-2xl flex items-center justify-end">
        <button type="submit"
                class="px-5 py-2.5 rounded-xl text-white bg-home-medigest hover:bg-home-medigest-hover">
          Atualizar password
        </button>
      </div>
    </form>
  </div>
</div>

@push('body-end')
<script>
  // Preview do avatar
  document.getElementById('avatar')?.addEventListener('change', (e) => {
    const [file] = e.target.files || [];
    if (!file) return;
    const url = URL.createObjectURL(file);
    const img = document.getElementById('avatarPreview');
    if (img) img.src = url;
  });
</script>
@endpush
@endsection
