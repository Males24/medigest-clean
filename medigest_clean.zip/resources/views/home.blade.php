@extends('layouts.app')

@section('title', 'MediGest+ | Página Inicial')

@section('content')
<div class="bg-white dark:bg-gray-900 min-h-screen">

    {{-- Hero Section com Título --}}
    <section class="text-center py-12 px-6">
        <h1 class="text-4xl md:text-5xl font-bold text-gray-800 dark:text-white mb-4 animate-fade-down">
            Bem-vindo à <span class="text-primary">MediGest+</span>
        </h1>
        <p class="text-lg text-gray-600 dark:text-gray-300 max-w-xl mx-auto animate-fade-up">
            A plataforma inteligente para gerir consultas, médicos e pacientes de forma fluída e eficiente.
        </p>
    </section>

    {{-- Carrossel Flowbite --}}
    <section class="max-w-5xl mx-auto mb-12">
        <div id="carouselExample" class="relative w-full" data-carousel="slide">
            <!-- Carousel wrapper -->
            <div class="relative h-64 overflow-hidden rounded-lg md:h-96">
                <div class="hidden duration-700 ease-in-out" data-carousel-item>
                    <img src="https://source.unsplash.com/1200x500/?doctor" class="block w-full object-cover" alt="Médico">
                </div>
                <div class="hidden duration-700 ease-in-out" data-carousel-item>
                    <img src="https://source.unsplash.com/1200x500/?hospital" class="block w-full object-cover" alt="Hospital">
                </div>
                <div class="hidden duration-700 ease-in-out" data-carousel-item>
                    <img src="https://source.unsplash.com/1200x500/?health" class="block w-full object-cover" alt="Saúde">
                </div>
            </div>
            <!-- Controls -->
            <button type="button" class="absolute top-0 left-0 z-30 flex items-center justify-center h-full px-4 group focus:outline-none" data-carousel-prev>
                <span class="inline-flex items-center justify-center w-10 h-10 rounded-full bg-white/30 group-hover:bg-white/50">
                    <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
                    </svg>
                </span>
            </button>
            <button type="button" class="absolute top-0 right-0 z-30 flex items-center justify-center h-full px-4 group focus:outline-none" data-carousel-next>
                <span class="inline-flex items-center justify-center w-10 h-10 rounded-full bg-white/30 group-hover:bg-white/50">
                    <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                    </svg>
                </span>
            </button>
        </div>
    </section>

    {{-- Ações principais --}}
    <section class="text-center mb-16 animate-fade-up" x-data="{ show: true }" x-show="show">
        <a href="{{ route('login.form') }}" class="px-6 py-3 bg-primary text-white rounded-md mx-2 hover:bg-blue-700 transition">Entrar</a>
        <a href="{{ route('register.form') }}" class="px-6 py-3 border border-primary text-primary rounded-md mx-2 hover:bg-primary hover:text-white transition">Criar Conta</a>
    </section>

</div>
@endsection
