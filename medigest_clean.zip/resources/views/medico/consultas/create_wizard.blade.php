@extends('layouts.dashboard')

@section('title','Marcar Consulta')

@section('content')
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10" data-page="wizard-consulta" data-role="medico">
  {{-- Título --}}
  <div class="mb-8">
    <h1 class="text-3xl font-semibold tracking-tight text-gray-900">Marcar Consulta</h1>
    <p class="text-sm text-gray-500 mt-1">Preenche os passos abaixo para agendar a consulta do paciente.</p>
  </div>

  {{-- STEPPER --}}
  <ol id="wizard-steps" class="flex items-center justify-between mb-5">
    @php $labels = ['Paciente','Tipo','Data & Hora','Duração','Descrição','Confirmar']; @endphp
    @foreach($labels as $i => $label)
      <li class="step-item flex items-center w-full">
        <div class="dot flex items-center justify-center w-9 h-9 rounded-full text-[13px] bg-gray-100 text-gray-500 ring-1 ring-gray-200">
          {{ $i+1 }}
        </div>
        <span class="label ml-2 text-sm sm:text-base text-gray-600 whitespace-nowrap">{{ $label }}</span>
        @if($i < count($labels)-1)
          <div class="line hidden sm:flex flex-1 h-0.5 bg-gray-200 mx-3"></div>
        @endif
      </li>
    @endforeach
  </ol>

  {{-- CARD --}}
  <form id="wizardForm" method="POST" action="{{ route('medico.consultas.store') }}"
        class="bg-white rounded-2xl shadow-sm ring-1 ring-gray-200/60">
    @csrf
    <input type="hidden" name="medico_id" value="{{ $medicoUserId }}">

    {{-- Conteúdo --}}
    <div class="p-6 sm:p-8 space-y-8">

      {{-- PASSO 0: Paciente --}}
      <section class="wizard-step" data-step="0">
        <h2 class="text-lg font-medium text-gray-900 mb-3">Selecionar paciente</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div class="sm:col-span-2">
            <label class="block text-sm font-medium text-gray-700 mb-1">Paciente</label>
            <select name="paciente_id" id="paciente_id"
                    class="w-full rounded-xl border-gray-300 focus:border-home-medigest-button focus:ring-home-medigest-button"
                    required>
              <option value="">-- Seleciona --</option>
              @foreach($pacientes as $p)
                <option value="{{ $p->id }}">{{ $p->name }} — {{ $p->email }}</option>
              @endforeach
            </select>
            <p class="text-xs text-gray-500 mt-1">Lista de utilizadores com perfil de paciente.</p>
          </div>
        </div>
      </section>

      {{-- PASSO 1: Tipo --}}
      <section class="wizard-step hidden" data-step="1">
        <h2 class="text-lg font-medium text-gray-900 mb-3">Tipo de consulta</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Tipo</label>
            <select id="tipo" name="tipo"
                    class="w-full rounded-xl border-gray-300 focus:border-home-medigest-button focus:ring-home-medigest-button">
              <option value="normal">Normal</option>
              <option value="prioritaria">Prioritária</option>
            </select>
            <p class="text-xs text-gray-500 mt-1">Prioritária pode ter lead time menor e horizonte maior.</p>
          </div>
        </div>
      </section>

      {{-- PASSO 2: Data & Hora --}}
      <section class="wizard-step hidden" data-step="2">
        <h2 class="text-lg font-medium text-gray-900 mb-3">Disponibilidade</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Data</label>
            <input type="date" id="data" name="data"
                   class="w-full rounded-xl border-gray-300 focus:border-home-medigest-button focus:ring-home-medigest-button"
                   required>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Hora (slots)</label>
            <select id="hora" name="hora"
                    class="w-full rounded-xl border-gray-300 focus:border-home-medigest-button focus:ring-home-medigest-button"
                    required>
              <option value="">— seleciona data —</option>
            </select>
            <p id="slotsMsg" class="text-xs text-gray-500 mt-1">Escolhe a data para ver as horas disponíveis.</p>
          </div>
        </div>
      </section>

      {{-- PASSO 3: Duração --}}
      <section class="wizard-step hidden" data-step="3">
        <h2 class="text-lg font-medium text-gray-900 mb-3">Duração</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Duração (min)</label>
            <select id="duracao" name="duracao"
                    class="w-full rounded-xl border-gray-300 focus:border-home-medigest-button focus:ring-home-medigest-button">
              <option value="15">15</option>
              <option value="30" selected>30</option>
              <option value="45">45</option>
              <option value="60">60</option>
            </select>
          </div>
        </div>
      </section>

      {{-- PASSO 4: Descrição --}}
      <section class="wizard-step hidden" data-step="4">
        <h2 class="text-lg font-medium text-gray-900 mb-3">Descrição do problema</h2>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-1">Detalhes (opcional)</label>
          <textarea id="motivo" name="motivo" rows="4"
                    class="w-full rounded-xl border-gray-300 focus:border-home-medigest-button focus:ring-home-medigest-button"
                    placeholder="Ex.: dores lombares, exame de rotina, etc."></textarea>
        </div>
      </section>

      {{-- PASSO 5: Confirmar --}}
      <section class="wizard-step hidden" data-step="5">
        <h2 class="text-lg font-medium text-gray-900 mb-3">Revisão</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-y-2 text-sm">
          <div class="text-gray-500">Médico</div>
          <div class="font-medium">{{ auth()->user()->name }}</div>

          <div class="text-gray-500">Paciente</div>
          <div class="font-medium" data-review="paciente">—</div>

          <div class="text-gray-500">Tipo</div>
          <div class="font-medium" data-review="tipo">—</div>

          <div class="text-gray-500">Data</div>
          <div class="font-medium" data-review="data">—</div>

          <div class="text-gray-500">Hora</div>
          <div class="font-medium" data-review="hora">—</div>

          <div class="text-gray-500">Duração</div>
          <div class="font-medium"><span data-review="duracao">—</span> min</div>

          <div class="text-gray-500">Descrição</div>
          <div class="font-medium" data-review="motivo">—</div>
        </div>
      </section>

    </div>

    {{-- FOOTER FIXO DO CARD --}}
    <div class="px-6 sm:px-8 py-4 bg-gray-50 rounded-b-2xl flex items-center justify-between">
      <button type="button" id="btnBack"
              class="px-4 py-2 rounded-xl border border-gray-300 text-gray-700 hover:bg-gray-100 disabled:opacity-50"
              disabled>
        Anterior
      </button>

      <div class="space-x-2">
        <button type="button" id="btnNext"
                class="px-5 py-2.5 rounded-xl bg-home-medigest text-white hover:bg-home-medigest-hover disabled:opacity-50">
          Seguinte
        </button>
        <button type="submit" id="btnSubmit"
                class="px-5 py-2.5 rounded-xl bg-green-600 text-white hover:bg-green-700 hidden">
          Agendar
        </button>
      </div>
    </div>
  </form>
</div>

@vite('resources/js/pages/consultas-wizard.js')
@endsection
