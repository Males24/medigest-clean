@extends('layouts.dashboard')

@section('title', 'Consultas - Admin')

@section('content')
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">

  {{-- Cabeçalho --}}
  <div class="flex items-center justify-between mb-6">
    <div>
      <h1 class="text-3xl font-semibold tracking-tight text-gray-900">Consultas</h1>
      <p class="text-sm text-gray-500 mt-1">Lista de todas as consultas registadas no sistema.</p>
    </div>
    <a href="{{ route('admin.consultas.create') }}"
       class="px-5 py-2.5 rounded-xl bg-home-medigest text-white hover:bg-home-medigest-hover shadow-sm">
      Nova Consulta
    </a>
  </div>

  {{-- Mensagens --}}
  @if(session('success'))
    <div class="mb-4 p-3 bg-green-100 text-green-800 rounded">{{ session('success') }}</div>
  @endif

  {{-- Tabela --}}
  <div class="bg-white rounded-2xl shadow-sm ring-1 ring-gray-200/60 overflow-x-auto">
    <table class="min-w-full text-sm text-left text-gray-600">
      <thead class="bg-gray-50 text-xs uppercase text-gray-500">
        <tr>
          <th class="px-6 py-3">Paciente</th>
          <th class="px-6 py-3">Médico</th>
          <th class="px-6 py-3">Data</th>
          <th class="px-6 py-3">Hora</th>
          <th class="px-6 py-3">Estado</th>
          <th class="px-6 py-3 text-right">Ações</th>
        </tr>
      </thead>
      <tbody>
        @foreach ($consultas as $consulta)
          <tr class="border-t border-gray-100 hover:bg-gray-50">
            <td class="px-6 py-3">{{ $consulta->paciente->name ?? '-' }}</td>
            <td class="px-6 py-3">{{ $consulta->medico->name ?? '-' }}</td>
            <td class="px-6 py-3">{{ $consulta->data }}</td>
            <td class="px-6 py-3">{{ $consulta->hora }}</td>
            <td class="px-6 py-3">{{ ucfirst($consulta->estado) }}</td>
            <td class="px-6 py-3 text-right">
              @if ($consulta->estado === 'agendada')
                <form method="POST" action="{{ route('admin.consultas.cancelar', $consulta) }}" class="inline">
                  @csrf
                  <button class="text-red-600 hover:underline" type="submit">Cancelar</button>
                </form>
              @endif
            </td>
          </tr>
        @endforeach
      </tbody>
    </table>
  </div>
</div>
@endsection
