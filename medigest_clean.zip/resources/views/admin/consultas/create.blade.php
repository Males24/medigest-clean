@extends('layouts.dashboard')

@section('title','Criar Consulta - Admin')

@section('content')
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10" data-page="wizard-consulta-admin" data-role="admin">
    {{-- Cabeçalho --}}
    <div class="flex items-center justify-between mb-8">
        <div>
            <h1 class="text-3xl font-semibold tracking-tight text-gray-900">Criar Consulta</h1>
            <p class="text-sm text-gray-500 mt-1">Preenche os passos para agendar a consulta.</p>
        </div>
        <a href="{{ route('admin.consultas.index') }}" class="text-gray-600 hover:underline">Voltar</a>
    </div>

    {{-- STEPPER --}}
    <ol id="wizard-steps" class="flex items-center justify-between mb-5">
        @php $labels = ['Paciente','Especialidade','Médico','Tipo','Data & Hora','Duração','Descrição','Confirmar']; @endphp
        @foreach($labels as $i => $label)
        <li class="step-head flex items-center w-full">
            <div class="flex items-center justify-center w-9 h-9 rounded-full text-[13px] bg-gray-100 text-gray-500 ring-1 ring-gray-200">
            {{ $i+1 }}
            </div>
            <span class="ml-2 text-sm sm:text-base text-gray-600 whitespace-nowrap">{{ $label }}</span>
            @if($i < count($labels)-1)
            <div class="hidden sm:flex flex-1 h-0.5 bg-gray-200 mx-3"></div>
            @endif
        </li>
        @endforeach
    </ol>

    {{-- CARD --}}
    <form id="wizardForm" method="POST" action="{{ route('admin.consultas.store') }}"
            class="bg-white rounded-2xl shadow-sm ring-1 ring-gray-200/60">
        @csrf

            <div class="p-6 sm:p-8 space-y-8">
                {{-- PASSO 0: Paciente --}}
                <section class="wizard-step" data-step="0">
                    <h2 class="text-lg font-medium text-gray-900 mb-3">Selecionar paciente</h2>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Paciente</label>
                    <select name="paciente_id" id="paciente_id"
                            class="w-full rounded-xl border-gray-300 focus:border-home-medigest-button focus:ring-home-medigest-button"
                            required>
                    <option value="">-- Seleciona --</option>
                    @foreach($pacientes as $p)
                        <option value="{{ $p->id }}">{{ $p->name }} — {{ $p->email }}</option>
                    @endforeach
                    </select>
                </section>

                {{-- PASSO 1: Especialidade --}}
                <section class="wizard-step hidden" data-step="1">
                    <h2 class="text-lg font-medium text-gray-900 mb-3">Especialidade</h2>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Especialidade</label>
                    <select name="especialidade_id" id="especialidade_id"
                            class="w-full rounded-xl border-gray-300 focus:border-home-medigest-button focus:ring-home-medigest-button"
                            required>
                    <option value="">-- Seleciona --</option>
                    @foreach($especialidades as $e)
                        <option value="{{ $e->id }}">{{ $e->nome }}</option>
                    @endforeach
                    </select>
                </section>

                {{-- PASSO 2: Médico --}}
                <section class="wizard-step hidden" data-step="2">
                    <h2 class="text-lg font-medium text-gray-900 mb-3">Selecionar médico</h2>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Médico</label>
                    <select name="medico_id" id="medico_id"
                            class="w-full rounded-xl border-gray-300 focus:border-home-medigest-button focus:ring-home-medigest-button"
                            required>
                    <option value="">— seleciona a especialidade —</option>
                    @foreach($medicos as $m)
                        <option value="{{ $m->id }}">{{ $m->name }} — {{ $m->email }}</option>
                    @endforeach
                    </select>
                    <p class="text-xs text-gray-500 mt-1">A lista é filtrada pela especialidade.</p>
                </section>

                {{-- PASSO 3: Tipo --}}
                <section class="wizard-step hidden" data-step="3">
                    <h2 class="text-lg font-medium text-gray-900 mb-3">Tipo de consulta</h2>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Tipo</label>
                    <select id="tipo" name="tipo"
                            class="w-full rounded-xl border-gray-300 focus:border-home-medigest-button focus:ring-home-medigest-button">
                    <option value="normal">Normal</option>
                    <option value="prioritaria">Prioritária</option>
                    </select>
                </section>

                {{-- PASSO 4: Data & Hora (slots por médico) --}}
                <section class="wizard-step hidden" data-step="4">
                <h2 class="text-lg font-medium text-gray-900 mb-3">Disponibilidade</h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Data</label>

                    {{-- Datepicker (Flowbite) --}}
                    <div class="relative max-w-sm z-50">
                        <div class="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
                        <svg class="w-4 h-4 text-gray-500" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M20 4a2 2 0 0 0-2-2h-2V1a1 1 0 0 0-2 0v1h-3V1a1 1 0 0 0-2 0v1H6V1a1 1 0 0 0-2 0v1H2a2 2 0 0 0-2 2v2h20V4ZM0 18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8H0v10Zm5-8h10a1 1 0 0 1 0 2H5a1 1 0 0 1 0-2Z"/>
                        </svg>
                        </div>

                        {{-- input visível (texto) --}}
                        <input
                        id="data_display"
                        type="text"
                        placeholder="Seleciona a data"
                        autocomplete="off"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg
                                focus:ring-blue-500 focus:border-blue-500 block w-full ps-10 p-2.5" />

                        {{-- input real enviado ao backend (YYYY-MM-DD) --}}
                        <input id="data" name="data" type="hidden" />
                    </div>
                    </div>

                    <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Hora (slots)</label>
                    <select id="hora" name="hora"
                            class="w-full rounded-xl border-gray-300 focus:border-home-medigest-button focus:ring-home-medigest-button"
                            required>
                        <option value="">— seleciona médico e data —</option>
                    </select>
                    <p id="slotsMsg" class="text-xs text-gray-500 mt-1">Escolhe médico e data para ver as horas disponíveis.</p>
                    </div>
                </div>
                </section>

                {{-- PASSO 5: Duração --}}
                <section class="wizard-step hidden" data-step="5">
                    <h2 class="text-lg font-medium text-gray-900 mb-3">Duração</h2>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Duração (min)</label>
                    <select id="duracao" name="duracao"
                            class="w-full rounded-xl border-gray-300 focus:border-home-medigest-button focus:ring-home-medigest-button">
                    <option value="15">15</option>
                    <option value="30" selected>30</option>
                    <option value="45">45</option>
                    <option value="60">60</option>
                    </select>
                </section>

                {{-- PASSO 6: Descrição --}}
                <section class="wizard-step hidden" data-step="6">
                    <h2 class="text-lg font-medium text-gray-900 mb-3">Descrição do problema</h2>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Detalhes (opcional)</label>
                    <textarea id="motivo" name="motivo" rows="4"
                            class="w-full rounded-xl border-gray-300 focus:border-home-medigest-button focus:ring-home-medigest-button"
                            placeholder="Ex.: dores lombares, exame de rotina, etc."></textarea>
                </section>

                {{-- PASSO 7: Confirmar --}}
                <section class="wizard-step hidden" data-step="7">
                    <h2 class="text-lg font-medium text-gray-900 mb-3">Revisão</h2>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-y-2 text-sm">
                    <div class="text-gray-500">Paciente</div>
                    <div class="font-medium" data-review="paciente">—</div>

                    <div class="text-gray-500">Especialidade</div>
                    <div class="font-medium" data-review="especialidade">—</div>

                    <div class="text-gray-500">Médico</div>
                    <div class="font-medium" data-review="medico">—</div>

                    <div class="text-gray-500">Tipo</div>
                    <div class="font-medium" data-review="tipo">—</div>

                    <div class="text-gray-500">Data</div>
                    <div class="font-medium" data-review="data">—</div>

                    <div class="text-gray-500">Hora</div>
                    <div class="font-medium" data-review="hora">—</div>

                    <div class="text-gray-500">Duração</div>
                    <div class="font-medium"><span data-review="duracao">—</span> min</div>

                    <div class="text-gray-500">Descrição</div>
                    <div class="font-medium" data-review="motivo">—</div>
                    </div>
                </section>
            </div>

            {{-- FOOTER --}}
            <div class="px-6 sm:px-8 py-4 bg-gray-50 rounded-b-2xl flex items-center justify-between">
                <button
                    type="button"
                    id="btnBack"
                    class="px-4 py-2 rounded-xl border border-gray-300 text-gray-700 hover:bg-gray-100 disabled:opacity-50"
                    style="visibility:hidden"
                    disabled
                >
                    Anterior
                </button>

                <div class="space-x-2">
                    <button type="button" id="btnNext"
                            class="px-5 py-2.5 rounded-xl bg-home-medigest text-white hover:bg-home-medigest-hover disabled:opacity-50">
                    Seguinte
                    </button>
                    <button type="submit" id="btnSubmit"
                            class="px-5 py-2.5 rounded-xl bg-green-600 text-white hover:bg-green-700 hidden">
                    Agendar
                    </button>
                </div>
            </div>
    </form>
</div>

@vite('resources/js/pages/consultas-admin-wizard.js')
@vite('resources/js/pages/datepicker-consultas.js')
@endsection
