<?php

namespace App\Services;

use App\Models\Consulta;
use App\Models\ConfiguracaoHorario; // horário GLOBAL
use App\Models\Horario; // horário por médico
use App\Models\ConfiguracaoAgenda;
use App\Models\ConsultaTipo;    
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class ConsultaService
{
    protected function loadAgendaGlobals(): array
    {
        $c = ConfiguracaoAgenda::first();
        return [
            'buffer_min' => $c->buffer_min ?? 10,
            'passo_min'  => $c->passo_min  ?? 30,
        ];
    }

    protected function getTipo(string $slug = 'normal'): ConsultaTipo
    {
        return ConsultaTipo::where('slug', $slug)->where('ativo', true)->firstOrFail();
    }

    protected function dentroFaixa(Carbon $inicio, Carbon $fim, ?string $faixaInicio, ?string $faixaFim): bool
    {
        if (!$faixaInicio || !$faixaFim) return false;
        $fIni = Carbon::createFromFormat('H:i', $faixaInicio);
        $fFim = Carbon::createFromFormat('H:i', $faixaFim);
        return $inicio->gte($fIni) && $fim->lte($fFim);
    }

    public function verificarDisponibilidade(
        int $medicoId,
        string $dataYmd,
        string $horaInicioHm,
        ?int $duracaoMin = null,
        string $tipoSlug = 'normal'
    ): bool {
        $globals = $this->loadAgendaGlobals();
        $tipo    = $this->getTipo($tipoSlug);

        $duracao = $duracaoMin ?: $tipo->duracao_min;
        $data    = Carbon::createFromFormat('Y-m-d', $dataYmd);
        $inicio  = Carbon::createFromFormat('H:i', $horaInicioHm);
        $fim     = (clone $inicio)->addMinutes($duracao);

        // Janela temporal: agora → agora + horizonte do tipo
        $limiteMax = now()->addHours($tipo->horizonte_horas)->startOfDay()->endOfDay();
        if ($data->lt(now()->startOfDay())) return false;
        if ($data->gt($limiteMax)) return false;

        // 1) Faixas do dia (global ou fallback médico)
        $faixas = [];
        $ch = ConfiguracaoHorario::where('dia_semana', $data->dayOfWeek)->where('ativo', true)->first();
        if ($ch) {
            if ($ch->manha_inicio && $ch->manha_fim) $faixas[] = [$ch->manha_inicio, $ch->manha_fim];
            if ($ch->tarde_inicio && $ch->tarde_fim) $faixas[] = [$ch->tarde_inicio, $ch->tarde_fim];
        } else {
            $horariosMed = Horario::where('medico_id', $medicoId)
                ->where('dia_semana', $data->dayOfWeek)
                ->where('disponivel', true)
                ->get();
            foreach ($horariosMed as $h) $faixas[] = [$h->hora_inicio, $h->hora_fim];
        }
        if (!$faixas) return false;

        $okFaixa = false;
        foreach ($faixas as [$ini, $fimFaixa]) {
            if ($this->dentroFaixa($inicio, $fim, $ini, $fimFaixa)) { $okFaixa = true; break; }
        }
        if (!$okFaixa) return false;

        // 2) Conflitos com consultas existentes (± buffer)
        $buffer    = (int) $globals['buffer_min'];
        $inicioBuf = (clone $inicio)->subMinutes($buffer)->format('H:i');
        $fimBuf    = (clone $fim)->addMinutes($buffer)->format('H:i');

        $existeConflito = Consulta::where('medico_id', $medicoId)
            ->where('data', $data->toDateString())
            ->whereIn('estado', ['agendada','confirmada','pendente_medico'])
            ->where(function ($q) use ($inicioBuf, $fimBuf) {
                $q->whereBetween('hora', [$inicioBuf, $fimBuf])
                  ->orWhereRaw('? BETWEEN hora AND ADDTIME(hora, SEC_TO_TIME(duracao * 60))', [$inicioBuf])
                  ->orWhereRaw('? BETWEEN hora AND ADDTIME(hora, SEC_TO_TIME(duracao * 60))', [$fimBuf]);
            })->exists();

        return !$existeConflito;
    }

    public function gerarSlotsDisponiveis(
        int $medicoId,
        string $dataYmd,
        ?int $duracaoMin = null,
        string $tipoSlug = 'normal'
    ): array {
        $globals = $this->loadAgendaGlobals();
        $tipo    = $this->getTipo($tipoSlug);
        $duracao = $duracaoMin ?: $tipo->duracao_min;

        $data = Carbon::createFromFormat('Y-m-d', $dataYmd);

        // Regras de janela temporal (aplicadas também no verificar)
        $limiteMax = now()->addHours($tipo->horizonte_horas)->startOfDay()->endOfDay();
        if ($data->lt(now()->startOfDay()) || $data->gt($limiteMax)) return [];

        // Faixas (global → fallback médico)
        $faixas = [];
        $ch = ConfiguracaoHorario::where('dia_semana', $data->dayOfWeek)->where('ativo', true)->first();
        if ($ch) {
            if ($ch->manha_inicio && $ch->manha_fim) $faixas[] = [$ch->manha_inicio, $ch->manha_fim];
            if ($ch->tarde_inicio && $ch->tarde_fim) $faixas[] = [$ch->tarde_inicio, $ch->tarde_fim];
        } else {
            $horariosMed = Horario::where('medico_id', $medicoId)
                ->where('dia_semana', $data->dayOfWeek)
                ->where('disponivel', true)
                ->get();
            foreach ($horariosMed as $h) $faixas[] = [$h->hora_inicio, $h->hora_fim];
        }
        if (!$faixas) return [];

        $slots = [];
        $passo = (int) $globals['passo_min'];

        foreach ($faixas as [$ini, $fim]) {
            $cursor = Carbon::createFromFormat('H:i', $ini);
            $limite = Carbon::createFromFormat('H:i', $fim);

            while ($cursor->lt($limite)) {
                $inicio  = $cursor->copy();
                $termino = $cursor->copy()->addMinutes($duracao);
                if ($termino->gt($limite)) break;

                if ($this->verificarDisponibilidade($medicoId, $dataYmd, $inicio->format('H:i'), $duracao, $tipoSlug)) {
                    $slots[] = $inicio->format('H:i');
                }
                $cursor->addMinutes($passo);
            }
        }

        return $slots;
    }

    public function agendarComTransacao(array $dados): ?int
    {
        return DB::transaction(function () use ($dados) {
            $ok = $this->verificarDisponibilidade(
                $dados['medico_id'],
                $dados['data'],
                $dados['hora'],
                (int)($dados['duracao'] ?? null),
                $dados['tipo_slug'] ?? ($dados['tipo'] ?? 'normal')
            );
            if (!$ok) return null;

            // garantir duracao/tipo
            $tipo = $this->getTipo($dados['tipo_slug'] ?? ($dados['tipo'] ?? 'normal'));
            $dados['duracao']   = $dados['duracao'] ?? $tipo->duracao_min;
            $dados['tipo_slug'] = $tipo->slug;

            $consulta = Consulta::create($dados);
            return $consulta->id;
        });
    }
}
