<?php

namespace App\Http\Controllers\Account;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    public function edit()
    {
        $user  = auth()->user();
        $prefs = array_merge([
            'theme'         => 'system',
            'language'      => 'pt-PT',
            'notify_email'  => true,
            'notify_push'   => false,
            'weekly_digest' => true,
        ], (array) ($user->settings ?? []));

        return view('account.settings', compact('user', 'prefs'));
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'theme'         => ['required', 'in:light,dark,system'],
            'language'      => ['required', 'in:pt-PT,en,es'],
            'notify_email'  => ['nullable', 'boolean'],
            'notify_push'   => ['nullable', 'boolean'],
            'weekly_digest' => ['nullable', 'boolean'],
        ]);

        // normaliza checkboxes (quando desligados não vêm no request)
        $prefs = [
            'theme'         => $data['theme'],
            'language'      => $data['language'],
            'notify_email'  => (bool) ($data['notify_email']  ?? false),
            'notify_push'   => (bool) ($data['notify_push']   ?? false),
            'weekly_digest' => (bool) ($data['weekly_digest'] ?? false),
        ];

        $user = $request->user();
        $user->settings = array_merge((array) $user->settings, $prefs);
        $user->save();

        return back()->with('success', 'Preferências guardadas.');
    }
}
