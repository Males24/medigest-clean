<?php

namespace App\Http\Controllers\Paciente;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

/** Home/landing do paciente. */
class PacienteController extends Controller
{
    public function index()
    {
        return view('paciente.home');
    }
}