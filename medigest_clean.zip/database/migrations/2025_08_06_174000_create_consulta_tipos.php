<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('consulta_tipos', function (Blueprint $t) {
            $t->id();
            $t->string('slug')->unique();     // normal, prioritaria, urgente
            $t->string('nome');
            $t->integer('horizonte_horas');   // p.ex. 720 = 30 dias
            $t->integer('duracao_min')->default(30);
            $t->boolean('ativo')->default(true);
            $t->timestamps();
        });

        // seed inicial mínima
        DB::table('consulta_tipos')->insert([
            ['slug'=>'normal','nome'=>'Normal','horizonte_horas'=>30*24,'duracao_min'=>30,'ativo'=>1],
            ['slug'=>'prioritaria','nome'=>'Prioritária','horizonte_horas'=>60*24,'duracao_min'=>30,'ativo'=>1],
            ['slug'=>'urgente','nome'=>'Urgente','horizonte_horas'=>72,'duracao_min'=>30,'ativo'=>1],
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('consulta_tipos');
    }
};
